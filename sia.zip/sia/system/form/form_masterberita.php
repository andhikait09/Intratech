<?php
function defBerita(){
echo" <div id=headermodul>Berita</div>
<div id=groupmodul1> <table id=tablemodul>
    <tr><td class=cc>Pilihan </td> <td colspan=2 class=cb> : <a href='?page=masterberita&PHPIdSession=tambahberita'>Tambah Pengumuman</a> </tr></td>
</table></form>"; 
echo"<table id=tablemodul>
    <tr><th>No</th><th>Tanggal</th><th>Isi Pengumuman</th><th>Aktif</th><th>Aksi</th></tr>";											
          $sql="SELECT t1.* FROM beritaawal t1 ORDER BY t1.id";
        	$qry= mysql_query($sql)
        	or die ();
        	while ($r=mysql_fetch_array($qry)){
          if(($no % 2)==0){
              $warna="#FFF";
          }
          else{
              $warna="#ebf0f5";
          }            	
        	$no++;
             echo "<tr bgcolor=$warna>                            
                   <td>$no</td>
                   <td>$r[tanggal]</td>
      		         <td>$r[isi]</td>
      		         <td>$r[aktif]</td>
                   <td>
                   <a href=\"?page=masterberita&PHPIdSession=delberita&gos=$r[id]\"
                   onClick=\"return confirm('Apakah Anda benar-benar akan menghapus $r[id] - $r[tanggal]?')\"><img src=../img/del.jpg></a></td></tr>";        
          } 
   echo" </table></div>";
}

function tambahberita(){
echo"<div id=groupmodul1>
    <form action='?page=masterberita&PHPIdSession=InputBerita' method='post'>
    <h3>Tambah Berita</h3>
    <table id=tablemodul>";              

	$sqlber = "select * from beritaawal order by id desc";
	$proses = mysql_query($sqlber);
	$record = mysql_fetch_array($proses);
	$id_ber= $record['id']+1;
echo"   
    <tr><td class=cc>Id :</td><td><input type=text name=id  value='$id_ber' size=10></td></tr>
	<tr><td class=cc>Tanggal :</td><td><input type=text name=tgl> * yyyy-mm-dd</td></tr>	
    <tr><td class=cc>Isi Pengumuman :</td><td><input type=text name=isi size=100></td></tr>
    <tr><td class=cc>Aktif :</td><td><input type=radio name=aktif value=Y> Y <input type=radio name=aktif value=N> N  </td></tr>           
    <tr><td colspan=2><input type=submit value=Simpan class=tombol> 
    <input type=button  class=tombol value=Batal onclick=self.history.back()>
    </td></tr></table></form></div>";
}

function editberita(){
$e=mysql_query("SELECT * FROM beritaawal WHERE id='$_GET[gis]'");
$d=mysql_fetch_array($e);

echo"<div id=groupmodul1>
    <form action='?page=masterberita&PHPIdSession=UpdateBerita' method='post'>
    <h3>Ubah Berita</h3>
    <table id=tablemodul>             
          <input type=hidden name=id value='$d[id]'>
<tr><td class=cc>Tanggal :</td><td><input type=text name=tgl value='$d[tanggal]'  size=20></td></tr> 		  
<tr><td class=cc>Isi Pengumuman :</td><td><input type=text name=isi value='$d[isi]'  size=100></td></tr>                  
<tr><td class=cc>Gambar :</td>       <td><input type=text name=gambar  value='$d[gambar]'></td></tr>";
          if ($d[aktif]=='Y'){
              echo "<tr><td class=cc>Aktif</td>    <td><input type=radio name=aktif value=Y checked>Y
                                                                              <input type=radio name=aktif value=N>N</td></tr>";
          }
          else{
              echo "<tr><td class=cc>Aktif</td>    <td><input type=radio name=aktif value=Y>Y
                                                                              <input type=radio name=aktif value=N checked>N</td></tr>";
          }
echo"           
<tr><td colspan=2><input type=submit value=Simpan class=tombol> <input type=button value=Batal class=tombol onClick=tb_remove() />
</td></tr></table></form></div>";
}
?>
