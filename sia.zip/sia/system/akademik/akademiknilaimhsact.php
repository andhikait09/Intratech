<?php
session_start();
include "../../config/koneksi.php";
include "../../librari/library.php";

$page=$_GET[page];

$act=$_GET[PHPIdSession];


if ($page=='akademiknilai' AND $act=='inputnilai'){
	
	if ($_GET['bbt'] == '4.00'){
		$grade ="A";
	}
	elseif($_GET['bbt'] == '3.75'){
		$grade ="A-";
	}
	elseif($_GET['bbt'] == '3.50'){
		$grade ="B+";
	}
	elseif($_GET['bbt'] == '3.00'){
		$grade ="B";
	}
	elseif($_GET['bbt'] == '2.75'){
		$grade ="B-";
	}
	elseif($_GET['bbt'] == '2.50'){
		$grade ="C+";
	}
	elseif($_GET['bbt'] == '2.00'){
		$grade ="C";
	}
	elseif($_GET['bbt'] == '1.75'){
		$grade ="C-";
	}
	elseif($_GET['bbt'] == '1.50'){
		$grade ="D";
	}
	elseif($_GET['bbt'] == '1.00'){
		$grade ="E";
	}
	elseif($_GET['bbt'] == '0.00'){
		$grade ="BL";
	}
	
    mysql_query("UPDATE krs SET GradeNilai  = '$grade',
                                 BobotNilai = '$_GET[bbt]'  
                           WHERE KRS_ID    = '$_GET[idk]'");

 header('location:../media.php?page=akademiknilai&PHPIdSession=inputnilai&ID='.$_REQUEST['ID'].'&kode='.$_REQUEST['kode'].'&idp='.$_REQUEST['idp'].'&tahun='.$_REQUEST['tahun'].'&mat='.$_REQUEST['mat'].'&idjadwal='.$_REQUEST['idjadwal']);
}                   
?>
