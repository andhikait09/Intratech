<?php 
  error_reporting(0);	
  session_start();
  include "../config/koneksi.php";
if (empty($_SESSION['username']) AND empty($_SESSION['password'])){
  header('location:../media.php?page=login');
}
else{
?>
<title>SIA v.112016</title>
<link rel="stylesheet" href="../css/all.css" type="text/css" />
<link rel="shortcut icon" href="../img/favicon.ico" />
<script src="../js/jquery.js" type="text/javascript"></script>
<script src="../js/jquery.form.js" type="text/javascript"></script>
<script src="../js/superfish.js" type="text/javascript"></script>
<script src="../js/tabs.js" type="text/javascript"></script>
	<script type="text/javascript">
      $(document).ready(function(){
			   $('ul.nav').superfish();
		  });	
  </script>
<body>
<div id="tabelsystem">
	<div id="menu">
		<ul class="nav">
		<?php 
			$level= $_SESSION['id_level'];
			function get_menu($data, $parent = 0) {
				static $i = 1;
				$tab = str_repeat(" ", $i);
				if (isset($data[$parent])) {
					$html = "$tab<ul class='sf-menu'>";
					$i++;
					foreach ($data[$parent] as $v) {
						$child = get_menu($data, $v->id_group);
						$html .= "$tab<li>";
						$html .= '<a href="'.$v->url.'">'.$v->judul.'</a>';
						if ($child) {
							$i--;
							$html .= $child;
							$html .= "$tab";
						}
						$html .= '</li>';
					}
					$html .= "$tab</ul>";
					return $html;
				} 
				else {
					return false;
				}
			}
			$result = mysql_query("SELECT *
									FROM hakmodul t1,dropdownsystem t2
									WHERE t1.id=t2.id AND t1.id_level='$level'
									ORDER BY t2.menu_order");
			while ($row = mysql_fetch_object($result)) {
				$data[$row->parent_id][] = $row;
			}
			$menu = get_menu($data);
			echo "$menu"; 
			?>
				<li class="sep">&nbsp;</li>
				<li class="right">&nbsp;</li>
		</ul>
		<?php
		}
		?>	
	</div>

	<div id="tabelkonten">
		<?php include "content.php"; ?>
	</div>
	<div id=footer><center>@2016 e-akademik v.112016 development by andhika</div>
</div>