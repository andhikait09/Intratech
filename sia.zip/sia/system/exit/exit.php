<?php
  //session_start();
  session_destroy();
echo"<div id=groupmodul1><div align=center>
  <table width=301>
    <tr>
      <td align='center' bgcolor='#FF0000'><div id='font-error'>PERHATIAN</div></td>
    </tr>
    <tr>
      <td align='center'>Silakan Klik Depan Jika Anda Ingin Kembali ke Menu awal: <a href='../index.php'>Depan</a></td>
    </tr>
  </table></div></div>";
?>
