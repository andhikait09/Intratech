<?php
switch($_GET[PHPIdSession]){
 // Semua content pada program terdapat pada folder form file form_program.php //
  default:
    defBerita();
  break;  

  case "tambahberita":
    tambahberita();     
  break;

  case "editberita":
    editberita();     
  break;
  
  case"InputBerita":
        $id     = $_POST['id_ber'];
        $tgl    = $_POST['tgl'];
        $isi    = $_POST['isi'];
		$gambar    = $_POST['gambar'];
        $aktif     = $_POST['aktif'];
        $cek=mysql_num_rows(mysql_query("SELECT * FROM beritaawal WHERE id='$id'"));
        if ($cek > 0){
            ?>
            <script>
             alert('Data Anda Sudah Ada,\n.');                    
            </script>
            <?php
        }
        else{        
        $query = "INSERT INTO beritaawal(id,tanggal,isi,gambar,aktif)VALUES('$id','$tgl','$isi','$gambar','$aktif')";
        mysql_query($query);
        }	  
    defBerita();
  break;

  case "UpdateBerita":
    $update=mysql_query("UPDATE beritaawal tanggal  = '$_POST[tgl]',
                                          isi  = '$_POST[isi]',
										  gambar  = '$_POST[gambar]',
                                          aktif       = '$_POST[aktif]'                                                                                   
                                    WHERE id          = '$_POST[id]'");
    $data=mysql_fetch_array($update);
    defBerita();    
  break;
  
  case "delberita";
        $sql="DELETE FROM beritaawal WHERE id='$_GET[gos]'";
       $qry=mysql_query($sql)
       or die();
    defBerita();
  break;
}
?>
