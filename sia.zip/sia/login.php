<?php
// Bagian Home
if  ($_GET['page']=='home'){
 echo"<div class=flat-form>
        <table id=kolomlogin>               
       <tr><th>Pendahuluan</th></tr>"; 
                $sql=mysql_query("SELECT * FROM beritaawal WHERE aktif='Y'");
                while($data=mysql_fetch_array($sql)){  
                echo "<tr><td>";
            
            	$kalimat=strtok(nl2br($data['isi'])," ");
                for ($i=1;$i<=100;$i++){
                  echo ($kalimat);
                  echo (" "); 
                  $kalimat=strtok(" "); 
                  }  
                }
   echo"</td></tr></table></div>";
  }
   
elseif  ($_GET['page']=='login'){
  echo"<div class='flat-form'>
    <table id=kolomlogin>
        <form method='POST' action='ceck.php'>    
        <tr>      
        <td><input type='text' name='username' id=username placeholder='nik atau nim'></td></tr>
        <tr><td><select name='id_level' id='selek'>
                                    <option value=0 selected >-level-</option>";
                                    $sql=mysql_query("SELECT * FROM level ORDER BY id_level");
                                    while($data=mysql_fetch_array($sql)){
                                    echo "<option value=$data[id_level]>$data[id_level] $data[level]</option>";
                                    }
        echo "</select></td></tr>
        <tr><td><input type='password' name='password' id=password placeholder='password'></td></tr>
        <tr><td><input type='submit' value='Login' class='tombol'></td></tr>  
        </form></table></div>";
		
}

elseif ($_GET['page']=='CekLogin'){
	$level= $_REQUEST['id_level'];
	$pass=md5($_POST['password']);
		if ($level==1) $tbl = 'admin';
			elseif ($level==2) $tbl = 'dosen';
			elseif ($level==3) $tbl = 'karyawan';
			elseif ($level==4) $tbl = 'mahasiswa';
			else
				header('location:media.php?page=login');
			
$login=mysql_query("SELECT * FROM $tbl WHERE username='$_POST[username]' AND password='$pass'")or die ("SQL Error:".mysql_error());
$ketemu=mysql_num_rows($login);
$data=mysql_fetch_array($login);

if ($ketemu > 0){
  session_start();
/*  
  session_register("username");
  session_register("password");
  session_register("id_level");
*/
  $_SESSION['username'] = $data['username'];
  $_SESSION['password'] = $data['password'];
  $_SESSION['id_level'] = $data['id_level'];

  header('location:system/media.php?page=home');
  
} 
else{
	header('location:media.php?page=login');
	}
}
?>
