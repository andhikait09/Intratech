<?php
  header('location:media.php?page=login'); 
?>
