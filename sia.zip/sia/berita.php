<div id="kepala">PENGUMUMAN PENTING </div>    
	<div id="badan">    
		<table width="100%" class="tableberita">
		<?php                
			$sql=mysql_query("SELECT * FROM beritaawal WHERE aktif='Y' ORDER BY id DESC");
			while($data=mysql_fetch_array($sql)){
		?>
		<tr>
          <td>| <?php echo $data['tanggal'] ?></td>
        </tr>
			<tr>
				<td><font color="#FF0000"><?php echo " $data[isi]" ?></td>
			</tr>
			<?php
			}
			?>
		</table>
	</div>