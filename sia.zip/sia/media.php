<?php 
  //error_reporting(0);
  ob_start();	
  session_start();
  include "config/koneksi.php";
?>
<title>e-akademik | </title>
<link rel="stylesheet" href="css/style.css" type="text/css" />
<link rel="stylesheet" href="css/login.css" type="text/css" />
<link rel="shortcut icon" href="img/favicon.ico" />
<meta name="keywords" content="sia" />
<meta name="description" content="sistem informasi akademik amik mahaputra" />
<meta name="robots" content="index, follow" />
<script src="js/jquery-1.4.js" type="text/javascript"></script>
<script src="js/superfish.js" type="text/javascript"></script>
<script src="js/hoverIntent.js" type="text/javascript"></script>
	<script type="text/javascript">
      $(document).ready(function(){
			   $('ul.nav').superfish();
		  });
  </script>
<style type="text/css">
</style>
<body>
<div id="kotakutama">
	<div id="tabellogo"><img src="img/header.jpg" ></div>
	<div id="tabellogin"><?php include "login.php"; ?></div>
	<div id="kolomberita"><?php include "berita.php"; ?></div>
	<div id=footer><center> e-akademik | @2016 development by Andhika,M.Kom</div>
</div>
