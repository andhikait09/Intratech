<script type="text/javascript" src="<?PHP echo MY_PATH?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?PHP echo MY_PATH?>js/camera.min.js"></script>
<script type="text/javascript" src="<?PHP echo MY_PATH?>js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="<?PHP echo MY_PATH?>js/costum.js"></script>