<script src="<?PHP echo MY_ADMIN?>js/jquery.min.js"></script>
<script src="<?PHP echo MY_ADMIN?>js/jquery.debouncedresize.min.js"></script>
<script src="<?PHP echo MY_ADMIN?>js/jquery.actual.min.js"></script>
	<script src="<?PHP echo MY_ADMIN?>js/jquery.cookie.min.js"></script>
<script src="<?PHP echo MY_ADMIN?>js/ios-orientationchange-fix.js"></script>

<script src="<?PHP echo MY_ADMIN?>js/bootstrap.plugins.min.js"></script>
<script src="<?PHP echo MY_ADMIN?>js/ios-orientationchange-fix.js"></script>
<!-- main bootstrap js -->
<script src="<?PHP echo MY_ADMIN?>bootstrap/js/bootstrap.min.js"></script>
<script src="<?PHP echo MY_ADMIN?>lib/qtip2/jquery.qtip.min.js"></script>
<script src="<?PHP echo MY_ADMIN?>lib/jBreadcrumbs/js/jquery.jBreadCrumb.1.1.min.js"></script>
<script src="<?PHP echo MY_ADMIN?>lib/sticky/sticky.min.js"></script>
<script src="<?PHP echo MY_ADMIN?>lib/antiscroll/antiscroll.js"></script>
<script src="<?PHP echo MY_ADMIN?>lib/antiscroll/jquery-mousewheel.js"></script>
<script src="<?PHP echo MY_ADMIN?>lib/jquery-ui/jquery-ui-1.8.20.custom.min.js"></script>

<!-- tag handler -->
<script src="<?PHP echo MY_ADMIN?>lib/tag_handler/jquery.taghandler.min.js"></script>
 <script src="<?PHP echo MY_ADMIN?>lib/uniform/jquery.uniform.min.js"></script>

<script src="<?PHP echo MY_ADMIN?>js/gebo_common.js"></script>
