<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Administrator</title>
<link rel="icon" type="image/gif" href="<?PHP echo MY_ADMIN?>img/agent.png">
<!-- Bootstrap framework -->
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>bootstrap/css/bootstrap-responsive.min.css" />
<!-- jQuery UI theme-->
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>lib/jquery-ui/css/Aristo/Aristo.css" />
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>lib/jBreadcrumbs/css/BreadCrumb.css" />
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>lib/qtip2/jquery.qtip.min.css" />
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>lib/sticky/sticky.css" />
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>lib/google-code-prettify/prettify.css" />    
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>lib/sticky/sticky.css" />    
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>img/splashy/splashy.css" />
<!-- datepicker -->
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>lib/datepicker/datepicker.css" />
<!-- tag handler -->
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>lib/tag_handler/css/jquery.taghandler.css" />
<!-- nice form elements -->
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>lib/uniform/Aristo/uniform.aristo.css" />
<!-- enhanced select -->
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>lib/chosen/coosen-css.css" />
<!-- upload -->
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>lib/plupload/js/jquery.plupload.queue/css/plupload-gebo.css" />
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>css/dark.css" id="link_theme" />
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>css/style.css" />
<link rel="stylesheet" href="<?PHP echo MY_ADMIN?>css/font-awesome.css" />
<!-- Favicon -->
<link rel="shortcut icon" href="<?PHP echo MY_ADMIN;?>img/agent.png" />
<!--[if lte IE 8]>
<link rel="stylesheet" href="css/ie.css" />
<script src="js/ie/html5.js"></script>
<script src="js/ie/respond.min.js"></script>
<![endif]-->