	
	<!-- start: Meta -->
	<meta charset="utf-8" />
	<title>Dashboard - Admin</title>
	<meta name="description" content="Dashboard - Admin" />
	<meta name="author" content="Dashboard - Admin" />
	<meta name="keyword" content="Dashboard - Admin" />
	<!-- end: Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
<link id="ie-style" href="css/ie.css" rel="stylesheet"><![endif]--><!--[if IE 9]><link id="ie9style" href="css/ie9.css" rel="stylesheet"><![endif]-->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="<?PHP echo MY_ADMIN?>img/favicon.png" />