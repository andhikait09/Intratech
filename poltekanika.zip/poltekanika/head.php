<link rel="stylesheet" type="text/css" href="<?PHP echo MY_PATH?>css/main.css" media="screen">

<link rel="stylesheet" type="text/css" href="<?PHP echo MY_PATH?>css/bootstrap.min.css" media="screen">
<link rel="stylesheet" type="text/css" href="<?PHP echo MY_PATH?>css/font-awesome.css">
<link rel="stylesheet" id="camera-css" href="<?PHP echo MY_PATH?>css/camera.css" type="text/css" media="all">
<script type='text/javascript' src='<?PHP echo MY_PATH?>js/jquery.js'></script>
<script src="<?PHP echo MY_PATH?>js/bootstrap.min.js"></script>

<script type="text/javascript">
// when the DOM is ready, convert the feed anchors into feed content
jQuery(document).ready(function() {

	jQuery('#newsslider').accessNews({
	
	});

});
</script>

