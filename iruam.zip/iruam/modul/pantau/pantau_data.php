<?php
$sql_ipcam = mysql_query("SELECT * FROM tb_ip_camera");
while ($dataipcam = mysql_fetch_array($sql_ipcam)){
	//$url="http://admin:admin@111501118406.speedyddns.net:8080";
	$userip=$dataipcam['ip_camera_username'];
	$passip=$dataipcam['ip_camera_password'];
	$urlaccess=$dataipcam['ip_camera_url_access'];
	$url="http://$userip:$passip@$urlaccess/cgi-bin/view/image";
?>
<iframe width="680" height="520" src="<?php echo $url ?>" ></iframe>
<?php
}
?>
<h5>Streaming IP Camera </h5>
