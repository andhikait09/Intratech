<?php
if(!$_POST[idtxt] || !$_POST[nm_ipcamtxt] || !$_POST[url_ipcamtxt] || !$_POST[user_ipcamtxt] || !$_POST[pass_ipcamtxt]){
	echo "<script>alert('Data tidak boleh ada yang kosong !')</script>";	
	echo "<meta http-equiv='refresh' content='0;home.php?go=ipcam_form'>";		
}else {
	$sql = "INSERT INTO tb_ip_camera(id_ip_camera,ip_camera_name,ip_camera_url_access,ip_camera_username,ip_camera_password) VALUES ('$_POST[idtxt]','$_POST[nm_ipcamtxt]','$_POST[url_ipcamtxt]','$_POST[user_ipcamtxt]','$_POST[pass_ipcamtxt]')";
	$proses = mysql_query($sql);
	if ($proses) {
		echo "<script>alert('Penyimpanan data berhasil !')</script>";
		echo "<meta http-equiv='refresh' content='0;home.php?go=ipcamera'>";
	} else { 
		echo "<script>alert('Penyimpanan data tidak berhasil !')</script>";
		echo "<meta http-equiv='refresh' content='0;home.php?go=ipcamera'>";
	}
}
?>
