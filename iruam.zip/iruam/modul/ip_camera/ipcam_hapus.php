<?php
$sql = "DELETE from tb_ip_camera where id ='$_GET[id]'";
$proses = mysql_query($sql);
	if ($proses) {
		echo "<script>alert('Penghapusan data berhasil !')</script>";
		echo "<meta http-equiv='refresh' content='0;home.php?go=ipcamera'>";
	} else { 
		echo "<script>alert('Penghapusan data tidak berhasil !')</script>";
		echo "<meta http-equiv='refresh' content='0;home.php?go=ipcamera'>";
	}
?>
