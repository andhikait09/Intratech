<table width="600" border="0" align="center" cellpadding="2" cellspacing="0" bgcolor="#FFFFFF">
<tr>
  <th width="49%" align="left" valign="middle" bgcolor="#8B9CC4" scope="col"><font color="#000000" face="Tahoma, Geneva, sans-serif" size="2"><b>DATA IP CAMERA</b></th>
  <th width="51%" align="right" valign="middle" bgcolor="#8B9CC4" scope="col"><font color="#000000" face="Tahoma, Geneva, sans-serif" size="2"><b><a href="home.php?go=ipcam_form"><img src="img/icon/tambah.png" alt="" width="16" height="16" /> tambah </a></b></font></th>
</tr>
</table>
<table width="600" border="0" align="center" cellpadding="4" cellspacing="0">
  <tr>
	<th align="center" scope="col" bgcolor="#CCCCCC">NO</th>
    <th align="center" scope="col" bgcolor="#CCCCCC">ID IPCAMERA</th>
    <th align="left" scope="col" bgcolor="#CCCCCC">CAMERA NAME</th>   
    <th align="right" scope="col" bgcolor="#CCCCCC">URL ACCESS</th> 
	<th align="right" scope="col" bgcolor="#CCCCCC">USERNAME</th> 
	<th align="right" scope="col" bgcolor="#CCCCCC">PASSWORD</th>         
    <th width="8%" align="Center" scope="col" bgcolor="#CCCCCC"><font color="#FFFFFF">ACTION</font></th>
</tr>

<?php
$no=1;
$sql = "select * from tb_ip_camera";
$proses = mysql_query($sql);
while ($record = mysql_fetch_array($proses))
{
?>
  <tr>
    <td align="center" scope="col" bgcolor="#FFFFFF"><?php echo $no ?></td>
    <td align="left" scope="col" bgcolor="#FFFFFF"><?php echo $record['id_ip_camera'] ?></td>
    <td align="left" scope="col" bgcolor="#FFFFFF"><?php echo $record['ip_camera_name']?></td>
    <td align="right" scope="col" bgcolor="#FFFFFF"><?php echo $record['ip_camera_url_access'] ?></td>
    <td align="right" scope="col" bgcolor="#FFFFFF"><?php echo $record['ip_camera_username']?></td>
	<td align="right" scope="col" bgcolor="#FFFFFF"><?php echo $record['ip_camera_password']?></td>
    <td align="Center" scope="col" bgcolor="#FFFFFF"><a href="?go=ipcam_form_ubah&amp;id=<?php echo $record['id_ip_camera']; ?>" title="Ubah Data" target="_self"><img src="img/icon/ubah.png" width="15" height="15" /></a>&nbsp;&nbsp;
	<a onclick="return confirm('Yakin data ini akan di hapus?');" href="?go=ipcam_hapus&amp;id=<?php echo $record['id_ip_camera']; ?>"><img src="img/icon/del.jpg" width="15" height="15" /></a></td>
  </tr>

<?php $no++;}?>

</table>
