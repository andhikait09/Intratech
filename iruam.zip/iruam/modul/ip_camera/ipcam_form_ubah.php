<?php
$sql = "select * from tb_ip_camera where id_ip_camera ='$_GET[id]'";
$proses = mysql_query($sql);
$record = mysql_fetch_array($proses);
?>
<form id="form1" name="form1" method="post" action="home.php?go=ipcam_ubah">
  <table width="400" border="0" align="center">
    <tr>
      <td width="30%" align="left" valign="middle">Id Ip Camera</td>
      <td width="2%" align="left" valign="middle">:</td>
      <td width="68%" align="left" valign="top"><input name="idtxt" type="text" id="idtxt" value="<?php echo $record['id_ip_camera'] ?>" size="5" maxlength="50" readonly="readonly" /></td>
    </tr>
    <tr>
      <td align="left" valign="middle">Nama Ip Camera</td>
      <td align="left" valign="middle">:</td>
      <td align="left" valign="top"><input name="nm_ipcamtxt" type="text" id="nm_ipcamtxt" size="50" maxlength="50" value="<?php echo $record['ip_camera_name'] ?>" /></td>
    </tr>
    <tr>
      <td align="left" valign="middle">Ip Camera URL Access</td>
      <td align="left" valign="middle">:</td>
      <td align="left" valign="top"><input name="url_ipcamtxt" type="text" id="url_ipcamtxt" size="50" maxlength="50" value="<?php echo $record['ip_camera_url_access'] ?>" /></td>
    </tr>
    <tr>
      <td align="left" valign="middle">Ip Camera Username</td>
      <td align="left" valign="middle">:</td>
      <td align="left" valign="top"><input name="username_ipcamtxt" type="text" id="username_ipcamtxt" size="50" maxlength="50" value="<?php echo $record['ip_camera_username'] ?>" /></td>
    </tr>
    <tr>
      <td align="left" valign="middle">Ip Camera Password</td>
      <td align="left" valign="middle">:</td>
      <td align="left" valign="top"><input name="password_ipcamtxt" type="text" id="password_ipcamtxt" size="50" maxlength="50" value="<?php echo $record['ip_camera_password'] ?>" /></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><label>
        <input type="submit" name="Submit" value="  Ubah  " />
        </label>
        </span></td>
    </tr>
  </table>
</form>
