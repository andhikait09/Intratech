<?php
$sql = "select * from tb_ip_camera";
$proses = mysql_query($sql);
$record = mysql_fetch_array($proses);
$kode = $record['id_ip_camera']+1;
?>
<form id="form1" name="form1" method="post" action="home.php?go=ipcam_simpan">
  <table width="700" border="0" align="center">
    <tr>
      <td width="40%" align="left" valign="middle">Id Ip Camera</td>
      <td width="2%" align="left" valign="middle">:</td>
      <td width="58%" align="left" valign="top"><input name="idtxt" type="text" id="idtxt" value="<?php echo $kode ?>" size="5" maxlength="50" readonly="readonly" /></td>
    </tr>
    <tr>
      <td align="left" valign="middle">Nama Ip Camera</td>
      <td align="left" valign="middle">:</td>
      <td align="left" valign="top"><input name="nm_ipcamtxt" type="text" id="nm_ipcamtxt" size="50" maxlength="50" /></td>
    </tr>
    <tr>
      <td align="left" valign="middle">Ip Camera URL Acces</td>
      <td align="left" valign="middle">:</td>
      <td align="left" valign="top"><input name="url_ipcamtxt" type="text" id="url_ipcamtxt" size="60" maxlength="70" /></td>
    </tr>
    <tr>
      <td align="left" valign="middle">Ip Camera User</td>
      <td align="left" valign="middle">:</td>
      <td align="left" valign="top"><input name="user_ipcamtxt" type="text" id="user_ipcamtxt" size="60" maxlength="70" /></td>
    </tr>
    <tr>
      <td align="left" valign="middle">Ip Camera Password</td>
      <td align="left" valign="middle">:</td>
      <td align="left" valign="top"><input name="pass_ipcamtxt" type="text" id="pass_ipcamtxt" size="60" maxlength="70" /></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><label>
        <input type="submit" name="Submit" value="Simpan" />
        </label>
        </span></td>
    </tr>
  </table>
</form>
