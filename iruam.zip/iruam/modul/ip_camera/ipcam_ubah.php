<?php
if(!$_POST[nm_ipcamtxt] || !$_POST[url_ipcamtxt] || !$_POST[username_ipcamtxt] || !$_POST[password_ipcamtxt]){
	echo "<script>alert('Data tidak boleh ada yang kosong !')</script>";	
	echo "<meta http-equiv='refresh' content='0;home.php?go=ipcamera'>";		
}else {
$sql = "UPDATE tb_ip_camera set ip_camera_name = '$_POST[nm_ipcamtxt]', ip_camera_url_access = '$_POST[url_ipcamtxt]', ip_camera_username = '$_POST[username_ipcamtxt]', ip_camera_password = '$_POST[password_ipcamtxt]' where id_ip_camera = '$_POST[idtxt]'";
$proses = mysql_query($sql);
	if ($proses) {
		echo "<script>alert('Pengubahan data berhasil !')</script>";
		echo "<meta http-equiv='refresh' content='0;home.php?go=ipcamera'>";
	} else { 
		echo "<script>alert('Pengubahan data tidak berhasil !')</script>";
		echo "<meta http-equiv='refresh' content='0;home.php?go=ipcamera'>";
	}
}
?>
