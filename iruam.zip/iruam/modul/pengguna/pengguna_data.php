<table width="600" border="0" align="center" cellpadding="2" cellspacing="0" bgcolor="#FFFFFF">
<tr>
  <th width="7%" align="left" valign="middle" bgcolor="#8B9CC4" scope="col"><font color="#000000" face="Tahoma, Geneva, sans-serif" size="2"><b>DATA PENGGUNA</b></th>
  <th width="7%" align="right" valign="middle" bgcolor="#8B9CC4" scope="col"><font color="#000000" face="Tahoma, Geneva, sans-serif" size="2"><b><a href="home.php?go=pengguna_form"><img src="img/icon/tambah.png" width="16" height="16" /> tambah</a></b></font></th>
</tr>
</table>
<table width="600" border="0" align="center" cellpadding="4" cellspacing="0">
<tr>
<td align="center" scope="col"  bgcolor="#CCCCCC"><b>No</b></th>
<td align="left" scope="col"  bgcolor="#CCCCCC"><b>Nick</b></th>
<td align="left" scope="col"  bgcolor="#CCCCCC"><b>Name Full</b></th>
<td align="left" scope="col"  bgcolor="#CCCCCC"><b>Email</b></th>
<td align="Center" scope="col"  bgcolor="#CCCCCC"><b><font color="#0000FF">Aksi</font></b></th>
</tr>
<?php
$no=1;
$query = "select * from tb_user";
$hasil = mysql_query($query);
while ($data = mysql_fetch_array($hasil))
{
?>
<tr>
<td align="center" scope="col" bgcolor="#FFFFFF"><?php echo $no ?></td>
<td align="left" scope="col" bgcolor="#FFFFFF"><?php echo $data['user_nick'] ?></td>
<td align="left" scope="col" bgcolor="#FFFFFF"><?php echo $data['user_name_full'] ?></td>
<td align="left" scope="col" bgcolor="#FFFFFF"><?php echo $data['user_email'] ?></td>
<td align="Center" scope="col" bgcolor="#FFFFFF"><a onclick="return confirm('Yakin data pengguna ini akan di hapus?');" href="?go=pengguna_hapus&amp;id=<?php echo $data['id_user']; ?>"><img src="img/icon/del.jpg" width="15" height="15" /></a></td>
</tr>
<?php $no++;} ?>
</table>