<?php 

if(!$_POST['pswlamatxt'] || !$_POST['pswbarutxt']){
	echo "<script>alert('Data tidak boleh ada yang kosong !')</script>";	
	echo "<meta http-equiv='refresh' content='0;home.php?go=pengguna_ubah_password_form'>";		
}else {

$password = nl2br($_POST['pswbarutxt']);
$password= str_replace("'","&acute;",$password);
	
$sql="select * from tb_user WHERE user_email='admin' and user_password = '".($_POST['pswlamatxt'])."'";
$proses=mysql_query($sql);
$cari = mysql_num_rows($proses);
if ($cari==0){
		echo "<script>alert('Password lama salah !')</script>";
		echo "<meta http-equiv='refresh' content='0;home.php?go=pengguna_ubah_password_form'>";
}else{
$sql2 = "UPDATE tb_user set user_password= '".$password."' where user_email= 'admin'";
$proses2 = mysql_query($sql2);
	if ($proses2) {
		echo "<script>alert('Perubahan password berhasil !')</script>";
		echo "<meta http-equiv='refresh' content='0;home.php?go=pengguna'>";
	} else { 		
		echo "<script>alert('Perubahan password tidak berhasil !')</script>";
		echo "<meta http-equiv='refresh' content='0;home.php?go=pengguna'>";
	}
}
}
?>