<?php
header("location:privat/login.php");
?>