<?php

include "citra.php";
$url="http://admin:admin@192.168.1.11/cgi-bin/view/image";
$citra = new OlahCitra;
$citra->getTemplate($url);

header('location:home.php?go=deteksi');

?>
