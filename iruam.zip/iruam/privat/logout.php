<?php 
session_start();
if(isset($_SESSION['user_email']))
	unset($_SESSION['user_password']);
	echo "<meta http-equiv='refresh' content='0;../index.php'>";
?>