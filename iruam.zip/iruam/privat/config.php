<?php 
date_default_timezone_set("Asia/Jakarta");
$host="localhost";
$user="root";
$pass="";
$db="iruam";
	
$koneksi=mysql_connect($host,$user,$pass); 
mysql_select_db($db,$koneksi);

if($koneksi){

}else{
echo'nampaknya koneksi database gagal';
}
?>