<?PHP 
include "config.php";

$username	= $_POST['user_name'];
$password	= md5($_POST['password']);
$sql=mysql_query("select * from tb_user where user_email='$username' and user_password='$password'");
$log=mysql_num_rows($sql);
$data= mysql_fetch_array($sql);
	
if ($log > 0){
	session_start();
	$_SESSION['id_user']		= $data['id_user'];
	$_SESSION['id_level']		= $data['id_level'];
	$_SESSION['user_nick']		= $data['user_nick'];
	$_SESSION['user_name_full']	= $data['user_name_full'];
	$_SESSION['user_password']	= $data['user_password'];
	$_SESSION['user_email']		= $data['user_email'];
		header("location:../home.php?go=home");	  
}else{
	header("location:login.php");	
}
?>