<!DOCTYPE html>
<html>
<head>
	<title>Sistem IP Camera</title>
	<meta http-equiv="refresh" content="4">
</head>
<body>
<?php
include "citra.php";
$url="http://admin:admin@192.168.1.11/cgi-bin/view/image";
?>

<div style="border:0px solid #000;padding:0px;margin:5px;">
<a href="template.php" style="border:1px solid #000;padding:5px;margin:5px;">Update Template</a><br>
<img width="400" src="<?php print $url; ?>" style="border:1px solid #000;padding:5px;margin:5px;"><br>
</div>

<div style="border:1px solid #000;padding:5px;margin:5px;background:#fff;">
<H3>PERINGATAN</H3>
<?php
$template = 'template/template1.jpg';
$citra = new OlahCitra;

$citra->komparasiGambar($template,$url,30,55,104,175,208,' Terdeteksi di jendela A');
echo " - Jendela A <br>";
$citra->komparasiGambar($template,$url,30,138,180,150,188,' Terdeteksi di jendela B');
echo " - Jendela B <br>";
$citra->komparasiGambar($template,$url,30,196,224,117,233,' Terdeteksi di Pintu');
echo " - Pintu <br>";
$citra->komparasiGambar($template,$url,30,416,427,113,147,' Terdeteksi di jendela C');
echo " - Jendela C <br><br>";
?>
</div>
</body>
</html>
