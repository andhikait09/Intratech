<?php
class PHPMailerlib {
    public function __construct() {
        require_once "PHPMailer/PHPMailerAutoload.php";
    }
}
?>