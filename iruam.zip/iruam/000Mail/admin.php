<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	var $base;
	var $css;
	var $img;
	var $sesnama;
	var $sesuser;
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
		$this->css = $this->config->item('css');
		$this->img = $this->config->item('images');
		$this->base = $this->config->item('base_url');
		$this->sesnama = $this->session->userdata('nama');
		$this->sesuser = $this->session->userdata('username');
		$this->load->library('PHPMailerlib');
		$this->load->library('tanggalidn');
		$this->load->model('ismail_model');
		date_default_timezone_set("Asia/Jakarta");
	}
	public function index()
	{
		if ($this->sesnama AND $this->sesuser )
		{
			$tgl = new Tanggalidn;
			$data['dash'] = 'active';
			$data['set'] = '';
			$data['notif'] = $this->ismail_model->getNewsToday();
			$data['nama'] = $this->sesnama;
			$data['news'] = $this->ismail_model->getNews();
			$data['tgl'] = $tgl;
			$this->load->view('admin/header', $data);
			$this->load->view('admin/main');
			$this->load->view('admin/footer');
		}
		else
		{
			redirect('../');
		}
	}
	public function notifNews()
	{
		$d = $this->ismail_model->getNewsToday();
		if ($d != 0)  { ?>
        	 <button type="button" class="btn btn-danger btn-xs"><?php print $d ?></button>
        <?php } else { ?>
        <?php }
	}
	public function setting()
	{
		if ($this->sesnama AND $this->sesuser )
		{
			$data['dash'] = '';
			$data['set'] = 'active';
			$data['nama'] = $this->sesnama;
			$this->load->view('admin/header', $data);
			$this->load->view('admin/setting');
			$this->load->view('admin/footer');
		}
		else
		{
			redirect('../');
		}
	}
	public function getFeed()
	{
		$feed = $this->ismail_model->getFeed();

		foreach ($feed as $f) {
			$data[$f->feed_id]['feed'] = $f->feed_name;
			$data[$f->feed_id]['feedid'] = $f->feed_id;
			$data[$f->feed_id]['judul'] = $f->feed_subject;
			$rss = simplexml_load_file($f->feed_link);

				if ($rss)
				{
				    $i = 0;
			    	foreach ($rss->channel->item as $item) {
			    		$link = (string) $item->link; // 
				        $title = (string) $item->title; //
				        $date = (string) $item->pubDate; //
				        $desc = (string) $item->description; //
						$pubDate = strftime("%Y-%m-%d", strtotime($date));
						$pubTime = strftime("%H:%M:%S", strtotime($date));
						$alldate = strftime("%Y-%m-%d %H:%M:%S", strtotime($date));

						$start = strtotime($pubDate);
						$end = strtotime(date('Y-m-d'));

						$days = ceil(abs($end - $start) / 86400);

						//print $days_between;
						if ($days < 4)
						{
							$data[$f->feed_id]['isi'][$i]['judul'] = $title;
				    		$data[$f->feed_id]['isi'][$i]['link'] = $link;
				    		$data[$f->feed_id]['isi'][$i]['date'] = $pubDate;
				    		$data[$f->feed_id]['isi'][$i]['dateo'] = $alldate;
				    		$data[$f->feed_id]['isi'][$i]['time'] = $pubTime;
				    		$data[$f->feed_id]['isi'][$i]['ago'] = $days;
				    		$data[$f->feed_id]['isi'][$i]['desc'] = $desc;
					        $i++;
						}
			    	}
				}
				else 
				{
				    echo 'Error!';
				}
			}

		return $data;
	}
	
	public function cekNews()
	{
		$data = $this->getFeed();
		//var_dump($data);
		if (!empty($data))
		{
			foreach ($data as $k) {
				foreach ($k['isi'] as $i) {
					if ($i['ago'] < 2)
					{
						$cek = $this->ismail_model->cekNews($i['judul'],$i['link']);
						if ($cek == 0)
						{
							$this->ismail_model->insertNews($k['feedid'],$i['judul'], $i['dateo'],$i['link']);
							$tr = 'true';
							break;
						}
						else
						{
							$tr = 'false';
						}
						
					}
					else
					{
						$tr = 'false';
					}
				}
			}
		}
		else
		{
			$tr = 'false';
		}
		
		//return $tr;
		print $tr;
	}

	public function mailFormat()
	{
		$msg = "";
		$tgl = new tanggalidn;
		$data = $this->getFeed();
		$msg .= "
		<html>
		<head>
		<style>
		body{
			font-family: Arial;
		}
		a {
			color: black;
			text-decoration: none;
			font-size: 12px;
		}
		a:hover{
			text-decoration: underline;
			color: blue;
		}
		hr {
			border-top:1px solid #dddddd;
			border-bottom: 1px solid #dddfff;
		}
		</style>
		</head>
		<body>
		<div style='font-weight:bold'>Informasi Terbaru dari Direktorat Jenderal Pendidikan Tinggi dan Kopertis Wilayah 10 Sumatera Barat, Riau, Jambi dan Kepulauan Riau</div><br>
		";
		foreach ($data as $d) {
			$judul = $d['judul'];
			foreach ($d['isi'] as $is) 
			{
				if ($is['ago'] < 3)
				{
							$msg .= '<a href="'.$is['link'].'">';
							$msg .= '<div style="font-size: 13px; font-weight:bold;">'.$judul.'';
							if ($is['ago'] == 0) { $msg .= ' Hari ini<br>';  } 
                            elseif ($is['ago'] == 1) { $msg .= ' Kemaren<br>'; } 
                            else { $msg .= ' | '.$is['ago'].' hari yang lalu<br>'; } 
                            $msg .= '</div>';
							$msg .= '<span style="font-size:10px;">'.$tgl->tglidn($is['date']).' '.$is['time'].'</span><br> ';
							$msg .= $is['judul'];
							$msg .= '</a><hr>';
				}	
			}
			
		}
		$msg .= '
		<div style="font-size:11px">
			Best Regards,<br>
			Muhammad Ihsan Zul via isaninside Mail Assistant - isMail 2014<br>
			Department of Computer - Head of Planning and Development<br>
			Politeknik Caltex Riau | ihsan@pcr.ac.id | http://isaninside.net | 085263476749<br>
		</div>
		</body>
		</html>';
		//print $msg;
		return $msg;
	}

	public function sendMail()
	{
		error_reporting(0);
		ini_set('display_errors', 0);
		$cek = $this->cekNews();

		print $cek;
		/*if ($cek == true)
		{
			$tgl = new tanggalidn;
		
			$mail = new PHPMailer;
			$mail->IsSMTP(); // send via SMTP 
			$mail->Host     = "smtp.gmail.com";      // sets GMAIL as the SMTP server
			$mail->SMTPAuth = true; // turn on SMTP authentication
			$mail->Username = ""; // Enter your SMTP username 
			$mail->Password = ""; // SMTP password 
			$mail->SMTPSecure = "tls";                 // sets the prefix to the servier
			$mail->Port       = 587;  

			$webmaster_email = "isaninside@gmail.com"; //Add reply-to email address 
			$email="ihsan@pcr.ac.id"; // Add recipients email address 
			$name="Pimpinan"; // Add Your Recipient’s name 

			$mail->From = $webmaster_email; 
			$mail->FromName = "isMail: Mail Assistant"; 
			$mail->AddAddress($email,$name); 
			$mail->AddReplyTo($webmaster_email,"isMail: Mail Assistant"); 
			$mail->IsHTML(true); // send as HTML 
			$mail->Subject = "isMail News Update: ".$tgl->tglidn(date('Y-m-d')).' '.date('H:i:s'); 
			$mail->MsgHTML = $this->mailFormat(); //HTML Body 
			$mail->Body = $this->mailFormat();
			$mail->AltBody = "Hi, this is your email body, etc, etc"; //Plain Text Body 
			if(!$mail->Send()){ 
				echo "Mailer Error: " . $mail->ErrorInfo; 
			} else { 
				echo "Message has been sent"; 
			} 
		}
		else
		{
			print 'There is no upcoming news!';
		}*/
		
	}
}
