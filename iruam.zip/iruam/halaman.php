<?php error_reporting(E_ERROR | E_WARNING | E_PARSE); ?>
<?php include "privat/config.php" ?>
<?php session_start();
	switch($_GET['go']){
		case 'home': 
			include("home_info.php"); 
		break;
		
		case 'login': 
			include("privat/login.php"); 
		break;
		
		case 'pengguna': 
			include("modul/pengguna/pengguna_data.php"); 
		break;	
		
		case 'pengguna_form': 
			include("modul/pengguna/pengguna_form.php"); 
		break;	
		
		case 'pengguna_simpan': 
			include("modul/pengguna/pengguna_simpan.php"); 
		break;			
		
		case 'pengguna_hapus': 
			include("modul/pengguna/pengguna_hapus.php"); 
		break;
		
		case 'pengguna_ubah_password_form': 
			include("modul/pengguna/pengguna_ubah_password_form.php"); 
		break;								
		
		case 'pengguna_ubah_password_simpan': 
			include("modul/pengguna/pengguna_ubah_password_simpan.php"); 
		break;	

		case 'pantau': 
			include("modul/pantau/pantau_data.php"); 
		break;		

		case 'ipcamera': 
			include("modul/ip_camera/ipcam_data.php"); 
		break;		
		
		case 'ipcam_form': 
			include("modul/ip_camera/ipcam_form.php"); 
		break;	
		
		case 'ipcam_simpan': 
			include("modul/ip_camera/ipcam_simpan.php"); 
		break;	
		
		case 'ipcam_form_ubah': 
			include("modul/ip_camera/ipcam_form_ubah.php"); 
		break;			
		
		case 'ipcam_ubah': 
			include("modul/ip_camera/ipcam_ubah.php"); 
		break;						
		
		case 'ipcam_hapus': 
			include("modul/ip_camera/ipcam_hapus.php"); 
		break;		
		
		case 'email': 
			include("email_data.php"); 
		break;		
		
		case 'email_form': 
			include("email_form.php"); 
		break;	
		
		case 'email_simpan': 
			include("email_simpan.php"); 
		break;	
		
		case 'email_form_ubah': 
			include("email_form_ubah.php"); 
		break;			
		
		case 'email_ubah': 
			include("email_ubah.php"); 
		break;						
		
		case 'email_hapus': 
			include("email_hapus.php"); 
		break;					
		
		case 'deteksi': 
			include("detect.php"); 
		break;		
		
		
	
		case '':
			include("home_info.php");		
		break;		
	};
?>	
