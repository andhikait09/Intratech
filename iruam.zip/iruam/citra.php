<?php
class OlahCitra
{
	// mengambil template
	public function getTemplate($url)
	{
			unlink("template/template1.jpg");
			$src = imagecreatefromjpeg($url);
			list($width,$height)=getimagesize($url);
			$nama_file = strtolower('template1.jpg');
			$lokasi = "template/$nama_file";
			imagejpeg($src,$lokasi,100);
			imagedestroy($src);
	}
	// ini mengubah warna jadi
	public function ubahwarna($im,$x,$y,$r,$g,$b)
	{
		imagesetpixel($im, $x, $y,imagecolorallocate($im, $r, $g, $b));
	}
	// belum dipake
	public function komparasiGambar($image1, $image2, $threshold,$y1, $y2, $x1, $x2, $pesan)
	{
		if (is_resource($image1))
		$im = $image1;
		else
		if (!$im = imagecreatefromjpeg($image1))
		trigger_error("Gambar 1 Tidak Ada di Direktori",E_USER_ERROR);
		 
		if (is_resource($image2))
		$im2 = $image2;
		else
		if (!$im2 = imagecreatefromjpeg($image2))
		trigger_error("Gambar 2 Tidak Ada di Direktori",E_USER_ERROR);
		 
		$perbedaanred = 0;
		$perbedaangreen = 0;
		$perbedaanblue = 0;
		$bedaPintu = 0;
		
		
		//tampilkan lebar
		//print 'Lebar image1: '.imagesx($im)."<br>";
		//print 'Lebar image2: '.imagesx($im2)."<br>";
		
		
		//tampilkan tinggi
		//print 'Tinggi image1: '.imagesy($im)."<br>";
		//print 'Tinggi image2: '.imagesy($im2)."<br>";
		 
		if (imagesx($im)!=imagesx($im2))
		die("Lebar antara Gambar 1 dan Gambar 2 Beda!");
		if (imagesy($im)!=imagesy($im2))
		die("Tinggi antara Gambar 1 dan Gambar 2 Beda!");
		$hitam = new OlahCitra;
		// pengecekan berdasarkan pixel dengan meninjau RGB masing-masing titik
		for ($width=$y1;$width<=$y2;$width++)
		{
			for ($height=$x1;$height<=$x2;$height++)
			{
				$rgb = imagecolorat($im, $width, $height);
				$r1 = ($rgb >> 16) & 0xFF;
				$g1 = ($rgb >> 8) & 0xFF;
				$b1 = $rgb & 0xFF;
				 
				$rgb2 = imagecolorat($im2, $width, $height);
				$r2 = ($rgb2 >> 16) & 0xFF;
				$g2 = ($rgb2 >> 8) & 0xFF;
				$b2 = $rgb2 & 0xFF;
				
				$w1 = ($r1+$g1+$b1)/3;
				$w2 = ($r2+$g2+$b2)/3;
				 
				if (!($w1>=$w2-$threshold && $w1<=$w2+$threshold))
				{	
					$bedaPintu++;
					//print $width.' '.$height.'<br>';
				}
			}
		}
		$TotalPixelRGB = (80*140)*3;
		$TotalPixelRGB = (($x2-$x1)*($y2-$y1));
		print "TotalPixel: ".$TotalPixelRGB.' | ';
		//$TotalPixelBeda = $perbedaanblue+$perbedaangreen+$perbedaanred;
		$TotalPixelBeda = $bedaPintu;
		//print "BedaPixel: ".$TotalPixelBeda.'<br>';
		$totalpixel = $TotalPixelRGB;
		$totalpixelbeda = $TotalPixelBeda;
		$PersentaseBeda = ($TotalPixelBeda/$TotalPixelRGB)*100;
		imagedestroy($im2);
		$persentase = round($PersentaseBeda,2);
		$date = date('Y-m-d H:i:s');
		print "PersentaseBeda: ".$persentase.' | ';
		if ($PersentaseBeda > 7)
		{
			date_default_timezone_get("Asia/Jakarta");
			require "000Mail/PHPMailer/PHPMailerAutoload.php";
			//require_once "000Mail/PHPMailer/class.phpmailer.php";
			
			$info = '1';
			$mail = new PHPMailer;
			$mail->IsSMTP(); // send via SMTP 
			$mail->Host     = "smtp.gmail.com";      // sets GMAIL as the SMTP server
			$mail->SMTPAuth = true; // turn on SMTP authentication
			$mail->Username = "april@mahasiswa.upi.ac.id"; // Enter your SMTP username 
			$mail->Password = "O61MOKQ0"; // SMTP password 
			$mail->SMTPSecure = "tls";                 // sets the prefix to the servier
			$mail->Port       = 587;

			$mail->From = "april@mahasiswa.upi.ac.id";
			$mail->FromName = "Alert System";

			$mail->AddAddress("andhika.it09@gmail.com", "andhika Phone");

			$mail->AddReplyTo("aprilia12tt@mahasiswa.pcr.ac.id","andhika"); 

			$mail->IsHTML(true); // send as HTML
			$mail->Subject = "iRuam Alert: ".date('Y-m-d').' '.date('H:i:s'); 
			$mail->Body = $pesan;

			$mail->AltBody = "Hi, this is your email body, etc, etc"; //Plain Text Body 
			if(!$mail->Send()){ 
				echo " Mailer Error: " . $mail->ErrorInfo; 
			} else { 
				echo " Message has been sent "; 
			} 
		}
		else
		{
			$info = '0';
			$pesan = " -> Tidak Ada Objek Ditemukan ! ";
			
		}
		print $pesan;
	}
}

?>