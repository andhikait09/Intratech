<link rel="stylesheet" type="text/css" href="menu/style.css" />
<script type="text/javascript" src="JQuery/jquery-1.9.1.js"></script>
<script type="text/javascript" src="JQuery/jquerycssmenu.js"></script>
<div id="myjquerymenu" class="jquerycssmenu">
<ul>
    <li><a href="home.php?go=pantau"><img src="img/icon/aman.png" /> Pantau</a></li>
	<li><a href="home.php?go=ipcamera"><img src="img/icon/streaming.png" /> Ip Camera</a></li>  
	<li><a href="home.php?go=deteksi"><img src="img/icon/deteksi.png" /> Deteksi</a></li>
    
    <li><a href="home.php?go=sistem"><img src="img/icon/developer.png" /> System</a></li>

		<li><a href="home.php?go=jadwal"><img src="img/icon/time.png" /> Mulai - Berakhir</a></li>          
	<li><a href="home.php?go=pengguna"><img src="img/icon/user.png" /> Pengguna</a></li> 
	<li><a href="home.php?go=pengguna_ubah_password_form"><img src="img/icon/ubah.png" /> Ubah Password</a></li>
    <li><a href="privat/logout.php"><img src="img/icon/logout.png" /> Log Out</a></li>                        
    </ul>
</div>
    
