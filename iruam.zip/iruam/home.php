<?php
session_start();
include "privat/config.php";
if (empty($_SESSION['user_email']) AND empty($_SESSION['user_password'])){
	header("location:privat/login.php");
}else{
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Apps</title>
<style type="text/css">
body,td,th {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 11px;
}
body {
	background-image: url(img/background.jpg);
}
.Area_Halaman {
	margin-top: 10px;
}
</style>
</head>
<link rel="stylesheet" type="text/css" href="menu/style.css" />
<script type="text/javascript" src="JQuery/jquery-1.9.1.js"></script>
<script type="text/javascript" src="JQuery/jquerycssmenu.js"></script>
<body>
<table style="border:1px solid #aaa;width:1000px;margin:0 auto;">
  <tr>
    <td colspan=2> APLIKASI TESIS BY ANDHIKA </td>
  </tr>
  <tr>
	<td style="border:1px solid #aaa;background:#FF0000;width:17%;"><?php include "menu.php" ?></td>
    <td style="border:1px solid #aaa;width:83%;"><div class="Area_Halaman"><?php include "halaman.php" ?></div></td>
  </tr>
  <tr>
    <td align="center" colspan=2><font color="#333">Aplikasi iRuam (Rumah Aman) v.01</font></td>
  </tr>
</table>
</body>
</html>
<?php
}
?>