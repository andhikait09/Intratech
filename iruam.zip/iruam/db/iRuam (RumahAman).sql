create table tb_level (
id_level int(5)not null,
level_nama varchar(30)not null,
level_info varchar(200)not null,
PRIMARY KEY (id_level)
)ENGINE=InnoDb;

create table tb_user (
id_user int(20)not null,
id_level int(5)not null,
user_nick varchar(50)not null,
user_name_full varchar(200)not null,
user_password varchar(100)not null,
user_email varchar(200)not null,
PRIMARY KEY (id_user)
)ENGINE=InnoDb;

create table tb_ip_camera_jadwal (
id_jadwal int(20)not null,
id_ip_camera int(200)not null,
jadwal_mulai TIME not null,
jadwal_selesai TIME not null,
PRIMARY KEY (id_jadwal)
)ENGINE=InnoDb;

create table tb_ip_camera_md_ref (
id_image int(100)not null,
id_ip_camera int(200)not null,
image_name varchar(100)not null,
image_date_time DATETIME not null,
PRIMARY KEY (id_image)
)ENGINE=InnoDb;

create table tb_ip_camera_notifikasi (
id_notifikasi int(100)not null,
id_ip_camera int(200)not null,
id_image_ref varchar(100)not null,
notifikasi_persentase varchar(100)not null,
notifikasi_image varchar(100)not null,
notifikasi_pesan varchar(100)not null,
notifikasi_tgl DATE not null,
notifikasi_jam TIME not null,
notifikasi_xy varchar(50)not null,
notifikasi_status ENUM('0','1')not null,
PRIMARY KEY (id_notifikasi)
)ENGINE=InnoDb;

create table tb_ip_camera (
id_ip_camera int(200)not null,
id_user int(20)not null,
ip_camera_status ENUM('0','1')not null,
ip_camera_md_status ENUM('0','1')not null,
ip_camera_name varchar(100)not null,
ip_camera_url varchar(200)not null,
ip_camera_url_access varchar(200)not null,
ip_camera_image_url varchar(200)not null,
ip_camera_image_url_access varchar(200)not null,
ip_camera_username varchar(100)not null,
ip_camera_password varchar(200)not null,
ip_camera_md_message varchar(200)not null,
ip_camera_date_added DATE not null,
PRIMARY KEY (id_ip_camera)
)ENGINE=InnoDb;

create table tb_sistem_informasi (
id_sistem varchar(100)not null,
sistem_deskripsi varchar(200)not null,
sistem_developer varchar(100)not null,
sistem_dev_email varchar(100)not null,
sistem_dev_website varchar(100)not null,
sistem_versi varchar(100)not null,
sistem_judul varchar(100)not null,
sistem_footer varchar(100)not null,
PRIMARY KEY (id_sistem)
)ENGINE=InnoDb;

create table tb_menu (
id_menu int(20)not null,
menu_name varchar(100)not null,
menu_kelompok varchar(50)not null,
menu_link varchar(100)not null,
menu_id_level varchar(50)not null,
menu_status ENUM('Y','N')not null,
PRIMARY KEY (id_menu)
)ENGINE=InnoDb;

