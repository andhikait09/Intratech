<?php

// Modul Front //
if ($_GET['hal']=='terbaru'){
include "modul/terbaru.php"; 
}

elseif ($_GET['hal']=='promo'){
    include "modul/sp.php"; 
}


elseif ($_GET['page']=='hasil'){  
    include "modul/hasil.php";
}

elseif ($_GET['page']=='hub'){  
    include "modul/hub.php";
}

// Apabila modul tidak ditemukan
else{
  echo "<p><b>MODUL BELUM ADA ATAU BELUM LENGKAP</b></p>";
}
?>