	<div class="container" style="margin-top:20px;">
		<footer class="text-center">
		<hr>
			<div class="col-md-12">
			<h6>Copyright ©2017 by amanstore.pe.hu | ASRI GROUP Pekanbaru | Riau online store</h6>
			<h6>Belanja Online Lebih Mudah, Murah, Gak Pake Ribet</h6>
			</div>
		</footer>
	</div> 
    <script src="<?php echo $url ?>assets/js/jquery.js"></script> 
    <script src="<?php echo $url ?>assets/bootstrap/js/bootstrap.min.js"></script> 
	<script src="<?php echo $url ?>assets/bootstrap/js/moment.js"></script>
	<script src="<?php echo $url ?>assets/bootstrap/js/bootstrap-datetimepicker.min.js"></script>
	<script type="text/javascript">
		$(function () {
			$('#datetimepicker').datetimepicker({
				format: 'YYYY-MM-DD',
            });
			$('#datetimepicker2').datetimepicker({
				format: 'YYYY-MM-DD',
			});
		});
	</script>
  </body>
</html>
