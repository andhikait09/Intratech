<?php 
	include "../inc/config.php"; 
	validate_admin_not_login("login.php");
	include "inc/header.php";
?> 
	
	<div class="container text-center" style="margin-top:20px;padding:50px;">
		
		<?php
			$q = mysql_query("select * from user WHere id='$_SESSION[iam_admin]'");
			$u = mysql_fetch_object($q);
		?>
		<h2>Hi, <?php echo $u->nama ?>. Info Hari Ini :</h2>
		<br>
		<div>
		<img class="navbar-logo" src="<?php echo $url.'assets/icon/1489958199_35_E-Commerce_Solution.png'; ?>"></img><a href="pesanan.php">Pesanan<?php if ($totalUnRead > 0) { ?> <span class="badge"><?php echo $totalUnRead; ?></span> <?php } ?></a> 
		<img class="navbar-logo" src="<?php echo $url.'assets/icon/1489958249_14_Payment.png'; ?>"></img><a href="pembayaran.php">Pembayaran <?php if ($totalPending > 0) { ?> <span class="badge"><?php echo $totalPending; ?></span> <?php } ?></a>
		</div>
    </div> <!-- /container -->
	
<?php include"inc/footer.php"; ?>