<?php
	include"inc/config.php"; 
	include"layout/header.php";	
?>
<div class="col-xs-12 col-md-12">
	<div class="row">
		<?php
			$q = mysql_query("Select * from info_pembayaran limit 1") or die (mysql_error());
			$data = mysql_fetch_object($q);
		?>
		<pre><?php echo $data->info; ?></pre>
	</div>
</div>
<?php
	include "layout/footer.php";
?>