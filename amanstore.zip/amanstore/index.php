<?php
  header('location:media.php?hal=terbaru'); 
?>