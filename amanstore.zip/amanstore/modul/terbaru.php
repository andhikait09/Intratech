<div class="col-md-12" >
	<div class="row">
	<div class="col-md-12">
	<h3>Terbaru</h3>
		<?php 
			$k = mysql_query("SELECT * FROM produk ORDER BY id DESC limit 60"); 
			while($data = mysql_fetch_array($k)){
		?>
		<div class="col-xs-6 col-md-2 content-menu">
			<a href="<?php echo $url; ?>menu.php?id=<?php echo $data['id'] ?>">
				<img src="<?php echo $url; ?>uploads/<?php echo $data['gambar'] ?>" width="100%">
				<h6><?php echo $data['nama'] ?></h6>
			</a>
			<p style="font-size:12px;color:red;font-weight:bold;">Harga : <?php echo number_format($data['harga'], 2, ',', '.') ?></p>
			<p>
				<a href="<?php echo $url; ?>menu.php?id=<?php echo $data['id'] ?>" class="btn btn-success btn-sm" href="#" role="button">Lihat Detail</a>
				<a href="<?php echo $url; ?>keranjang.php?act=beli&&produk_id=<?php echo $data['id'] ?>" class="btn btn-info btn-sm" href="#" role="button">Pesan</a>
			</p>
		</div>  
		<?php } ?>
		
	</div>
	</div>


</div>