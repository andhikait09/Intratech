<div class="col-md-12">
	<div class="row">
		<div class="col-md-12">
			<hr>
			<h3>Spesial Promo</h3>
				<?php 
					$k = mysql_query("SELECT * FROM produk where kategori_produk_id=1 order by id desc");
					while($data = mysql_fetch_array($k)){
				?>
				<div class="col-xs-6 col-md-2 content-menu">
					<a href="<?php echo $url; ?>menu.php?id=<?php echo $data['id'] ?>">
						<img src="<?php echo $url; ?>uploads/<?php echo $data['gambar'] ?>" width="100%">
						<h4><?php echo $data['nama'] ?></h4>
					</a>
					<p style="font-size:18px">Harga :<?php echo number_format($data['harga'], 2, ',', '.') ?></p>
					<p>
						<a href="<?php echo $url; ?>menu.php?id=<?php echo $data['id'] ?>" class="btn btn-success btn-sm" href="#" role="button">Lihat Detail</a>
						<a href="<?php echo $url; ?>keranjang.php?act=beli&&produk_id=<?php echo $data['id'] ?>" class="btn btn-info btn-sm" href="#" role="button">Pesan</a>
					</p>
				</div>  
				<?php } ?>				
		</div>
	</div>
</div>
