<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
</div></article></div></div></div></div>
<footer class="footer"><p><?php echo setting('web_judul').' - '.setting('sekolah_nama'); ?></p></footer>
</div></div></body></html>