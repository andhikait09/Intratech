-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2015 at 12:46 AM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `psb`
--

-- --------------------------------------------------------

--
-- Table structure for table `agama`
--

CREATE TABLE IF NOT EXISTS `agama` (
  `agama_id` int(11) NOT NULL,
  `agama_nama` varchar(64) NOT NULL,
  `agama_keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `agama`
--

INSERT INTO `agama` (`agama_id`, `agama_nama`, `agama_keterangan`) VALUES
(1, 'Islam', NULL),
(2, 'Katolik', NULL),
(3, 'Kristen', NULL),
(4, 'Hindu', NULL),
(7, 'Budha', NULL),
(8, 'Konghuchu', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `captcha`
--

CREATE TABLE IF NOT EXISTS `captcha` (
  `captcha_id` bigint(13) unsigned NOT NULL,
  `captcha_time` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `word` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `captcha`
--

INSERT INTO `captcha` (`captcha_id`, `captcha_time`, `ip_address`, `word`) VALUES
(20, 1447717517, '::1', '02pdr9v9');

-- --------------------------------------------------------

--
-- Table structure for table `gelombang`
--

CREATE TABLE IF NOT EXISTS `gelombang` (
  `gel_id` int(11) NOT NULL,
  `gel_ta` year(4) NOT NULL,
  `gel_kode` int(4) NOT NULL,
  `gel_nama` varchar(128) NOT NULL,
  `gel_tanggal_mulai` date NOT NULL,
  `gel_tanggal_selesai` date NOT NULL,
  `gel_jumlah_pilihan` smallint(2) NOT NULL DEFAULT '1',
  `gel_keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gelombang`
--

INSERT INTO `gelombang` (`gel_id`, `gel_ta`, `gel_kode`, `gel_nama`, `gel_tanggal_mulai`, `gel_tanggal_selesai`, `gel_jumlah_pilihan`, `gel_keterangan`) VALUES
(6, 2015, 1501, 'Gelombang I', '2015-10-01', '2015-12-31', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jenis_test`
--

CREATE TABLE IF NOT EXISTS `jenis_test` (
  `jentest_id` int(11) NOT NULL,
  `jentest_gel` int(11) DEFAULT NULL,
  `jentest_nama` varchar(64) NOT NULL,
  `jentest_singkatan` char(16) DEFAULT NULL,
  `jentest_persen` decimal(5,2) NOT NULL,
  `jentest_keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jenis_test`
--

INSERT INTO `jenis_test` (`jentest_id`, `jentest_gel`, `jentest_nama`, `jentest_singkatan`, `jentest_persen`, `jentest_keterangan`) VALUES
(2, 6, 'Test Wawancara', 'TW', '10.00', NULL),
(3, 6, 'Mahasiswa Undangan', 'MU', '80.00', NULL),
(4, 6, 'Test Tertulis', 'TT', '10.00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jurusan`
--

CREATE TABLE IF NOT EXISTS `jurusan` (
  `jur_id` int(11) NOT NULL,
  `jur_nama` varchar(128) NOT NULL,
  `jur_singkatan` char(16) DEFAULT NULL,
  `jur_no_sk` varchar(255) DEFAULT NULL,
  `jur_tanggal` date DEFAULT NULL,
  `jur_keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jurusan`
--

INSERT INTO `jurusan` (`jur_id`, `jur_nama`, `jur_singkatan`, `jur_no_sk`, `jur_tanggal`, `jur_keterangan`) VALUES
(1, 'Manajemen Informatika', 'MI', NULL, '2009-11-01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `kuota`
--

CREATE TABLE IF NOT EXISTS `kuota` (
  `kuota_id` int(11) NOT NULL,
  `kuota_gel` int(11) DEFAULT NULL,
  `kuota_jur` int(11) DEFAULT NULL,
  `kuota_jumlah` int(11) NOT NULL,
  `kuota_cadangan` int(11) NOT NULL,
  `kuota_keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kuota`
--

INSERT INTO `kuota` (`kuota_id`, `kuota_gel`, `kuota_jur`, `kuota_jumlah`, `kuota_cadangan`, `kuota_keterangan`) VALUES
(11, 6, 1, 500, 5, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `link`
--

CREATE TABLE IF NOT EXISTS `link` (
  `link_id` int(11) NOT NULL,
  `link_text` varchar(255) NOT NULL,
  `link_url` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `link`
--

INSERT INTO `link` (`link_id`, `link_text`, `link_url`) VALUES
(6, 'FaceBook', 'http://facebook.com'),
(7, 'Twitter', 'http://twitter.com'),
(8, 'Google', 'google.com');

-- --------------------------------------------------------

--
-- Table structure for table `mata_pelajaran`
--

CREATE TABLE IF NOT EXISTS `mata_pelajaran` (
  `mapel_id` int(11) NOT NULL,
  `mapel_gel` int(11) DEFAULT NULL,
  `mapel_nama` varchar(64) NOT NULL,
  `mapel_singkatan` char(16) DEFAULT NULL,
  `mapel_keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mata_pelajaran`
--

INSERT INTO `mata_pelajaran` (`mapel_id`, `mapel_gel`, `mapel_nama`, `mapel_singkatan`, `mapel_keterangan`) VALUES
(4, 6, 'Matematika', 'MAT', NULL),
(7, 6, 'Bahasa Inggris', 'BI', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE IF NOT EXISTS `nilai` (
  `nilai_id` int(11) NOT NULL,
  `nilai_siswa` int(11) DEFAULT NULL,
  `nilai_mapel` int(11) DEFAULT NULL,
  `nilai_uan` decimal(5,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`nilai_id`, `nilai_siswa`, `nilai_mapel`, `nilai_uan`) VALUES
(4, 1, 4, '0.00'),
(7, 1, 7, '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `orang_tua`
--

CREATE TABLE IF NOT EXISTS `orang_tua` (
  `ot_id` int(11) NOT NULL,
  `ot_siswa` int(11) DEFAULT NULL,
  `ot_nama_ayah` varchar(255) DEFAULT NULL,
  `ot_pend_ayah` int(11) DEFAULT NULL,
  `ot_pek_ayah` int(11) DEFAULT NULL,
  `ot_gaji_ayah` char(16) DEFAULT NULL,
  `ot_hp_ayah` varchar(16) DEFAULT NULL,
  `ot_nama_ibu` varchar(255) DEFAULT NULL,
  `ot_pend_ibu` int(11) DEFAULT NULL,
  `ot_pek_ibu` int(11) DEFAULT NULL,
  `ot_gaji_ibu` char(16) DEFAULT NULL,
  `ot_hp_ibu` varchar(16) DEFAULT NULL,
  `ot_alamat_ortu` varchar(255) DEFAULT NULL,
  `ot_nama_wali` varchar(255) DEFAULT NULL,
  `ot_pend_wali` int(11) DEFAULT NULL,
  `ot_pek_wali` int(11) DEFAULT NULL,
  `ot_gaji_wali` char(16) DEFAULT NULL,
  `ot_hp_wali` varchar(16) DEFAULT NULL,
  `ot_alamat_wali` varchar(255) DEFAULT NULL,
  `ot_status_asuh` enum('ortu','wali') DEFAULT 'ortu'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orang_tua`
--

INSERT INTO `orang_tua` (`ot_id`, `ot_siswa`, `ot_nama_ayah`, `ot_pend_ayah`, `ot_pek_ayah`, `ot_gaji_ayah`, `ot_hp_ayah`, `ot_nama_ibu`, `ot_pend_ibu`, `ot_pek_ibu`, `ot_gaji_ibu`, `ot_hp_ibu`, `ot_alamat_ortu`, `ot_nama_wali`, `ot_pend_wali`, `ot_pek_wali`, `ot_gaji_wali`, `ot_hp_wali`, `ot_alamat_wali`, `ot_status_asuh`) VALUES
(1, 1, NULL, 2, 1, NULL, NULL, NULL, 2, 1, NULL, NULL, NULL, NULL, 2, 1, NULL, NULL, NULL, 'ortu');

-- --------------------------------------------------------

--
-- Table structure for table `pekerjaan`
--

CREATE TABLE IF NOT EXISTS `pekerjaan` (
  `pek_id` int(11) NOT NULL,
  `pek_nama` varchar(64) NOT NULL,
  `pek_keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pekerjaan`
--

INSERT INTO `pekerjaan` (`pek_id`, `pek_nama`, `pek_keterangan`) VALUES
(1, 'PNS', NULL),
(2, 'Swasta', NULL),
(3, 'TNI/POLRI', NULL),
(4, 'Petani', NULL),
(5, 'Wiraswasta', NULL),
(6, 'Buruh', NULL),
(7, 'Lain-Lain', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan`
--

CREATE TABLE IF NOT EXISTS `pendidikan` (
  `pend_id` int(11) NOT NULL,
  `pend_nama` varchar(64) NOT NULL,
  `pend_keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pendidikan`
--

INSERT INTO `pendidikan` (`pend_id`, `pend_nama`, `pend_keterangan`) VALUES
(1, 'Tidak Tamat SD', NULL),
(2, 'SD', NULL),
(3, 'SMP', NULL),
(4, 'SMA', NULL),
(5, 'Diploma 1', NULL),
(6, 'Diploma 2', NULL),
(7, 'Diploma 3', NULL),
(8, 'S1', NULL),
(9, 'S2', NULL),
(10, 'S3', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pilihan`
--

CREATE TABLE IF NOT EXISTS `pilihan` (
  `pilihan_id` int(11) NOT NULL,
  `pilihan_siswa` int(11) DEFAULT NULL,
  `pilihan_jur` int(11) DEFAULT NULL,
  `pilihan_ke` smallint(1) NOT NULL,
  `pilihan_status` enum('kosong','diterima','cadangan','ditolak') DEFAULT 'kosong'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pilihan`
--

INSERT INTO `pilihan` (`pilihan_id`, `pilihan_siswa`, `pilihan_jur`, `pilihan_ke`, `pilihan_status`) VALUES
(1, 1, 1, 1, 'diterima'),
(2, 1, NULL, 2, 'kosong'),
(3, 1, NULL, 3, 'kosong');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE IF NOT EXISTS `post` (
  `post_id` int(11) NOT NULL,
  `post_judul` text NOT NULL,
  `post_link` text NOT NULL,
  `post_isi` longtext,
  `post_user` int(11) DEFAULT NULL,
  `post_tanggal` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `post_judul`, `post_link`, `post_isi`, `post_user`, `post_tanggal`) VALUES
(1, 'Motto', 'motto', '<p><strong>Tujuan</strong></p>\r\n<ol>\r\n<li>civitas akademika yang mampu menjadi teladan dalam kehidupan masyarakat.</li>\r\n<li>Meningkatkan Mewujudkan kegiatan penelitian sebagai landasan penyelenggaraan pendidikan dan pengembangan IPTEK.</li>\r\n<li>Menghasilkan lulusan yang menguasai iptek dan seni, beriman dan bertaqwa, serta profesional, kreatif, inovatif, dan mampu beradaptasi serta berpartisipasi dalam&nbsp; masyarakat.</li>\r\n<li>Menjalin kerjasama dengan berbagai pihak dalam pengembangan pendidikan dan penelitian serta IPTEK.</li>\r\n</ol>', 1, '2015-03-01'),
(3, 'Visi dan Misi', 'visi-dan-misi', '<p><strong>Visi :</strong></p>\r\n<p><strong>Menjadi perguruan tinggi terdepan pada tahun 2022 dalam menghasilkan sumber daya manusia dibidang teknologi informasi, dan memberikan kontribusi dalam bidang pendidikan, penelitian dan pengabdian pada masyarakat. </strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>Misi :</strong></p>\r\n<ol>\r\n<li>Memberikan pelayanan prima agar terciptanya suasana kondusif bagi penyelenggaraan Tri Dharma perguruan tinggi.</li>\r\n<li>Menyelenggarakan program Diploma Tiga D (III) berbasis teknologi informasi yang mendukung peningkatan sumber daya manusia.</li>\r\n<li>Meningkatkan kualitas SDM secara berkesinambungan dalam rangka penjaminan mutu lulusan.</li>\r\n<li>Mengembangkan tata kelola efektif dan efesien yang dapat menyikapi perubahan yang terjadi.</li>\r\n</ol>', 1, '2015-03-01');

-- --------------------------------------------------------

--
-- Table structure for table `prestasi`
--

CREATE TABLE IF NOT EXISTS `prestasi` (
  `prestasi_id` int(11) NOT NULL,
  `prestasi_siswa` int(11) DEFAULT NULL,
  `prestasi_nilai` decimal(5,1) DEFAULT '0.0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prestasi`
--

INSERT INTO `prestasi` (`prestasi_id`, `prestasi_siswa`, `prestasi_nilai`) VALUES
(1, 1, '0.0');

-- --------------------------------------------------------

--
-- Table structure for table `provinsi`
--

CREATE TABLE IF NOT EXISTS `provinsi` (
  `prov_id` int(11) NOT NULL,
  `prov_nama` varchar(64) NOT NULL,
  `prov_pulau` varchar(64) DEFAULT NULL,
  `prov_keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `provinsi`
--

INSERT INTO `provinsi` (`prov_id`, `prov_nama`, `prov_pulau`, `prov_keterangan`) VALUES
(1, 'Jawa Tengah', 'Jawa', 'Semarang'),
(2, 'Sumatera Utara', 'Sumatera', 'Medan'),
(3, 'Sumatera Barat', 'Sumatera', 'Padang'),
(4, 'Riau', 'Sumatera', 'Pekanbaru'),
(5, 'Kepulauan Riau', 'Sumatera', 'Tanjung Pinang'),
(6, 'Jambi', 'Sumatera', 'Jambi'),
(7, 'Sumatera Selatan', 'Sumatera', 'Palembang'),
(8, 'Bangka Belitung', 'Sumatera', 'Pangkal Pinang'),
(9, 'Bengkulu', 'Sumatera', 'Bengkulu'),
(10, 'Lampung', 'Sumatera', 'Bandar Lampung'),
(11, 'DKI Jakarta', 'Jawa', 'Jakarta'),
(12, 'Jawa Barat', 'Jawa', 'Bandung'),
(13, 'Banten', 'Jawa', 'Serang'),
(14, 'Daerah Istimewa Yogyakarta', 'Jawa', 'Yogyakarta'),
(15, 'Nanggro Aceh Darussalam', 'Sumatera', 'Banda Aceh'),
(16, 'Jawa Timur', 'Jawa', 'Surabaya'),
(17, 'Bali', 'Bali', 'Denpasar'),
(18, 'Nusa Tenggara Barat', 'Nusa Tenggara', 'Mataram'),
(19, 'Nusa Tenggara Timur', 'Nusa Tenggara', 'Kupang'),
(20, 'Kalimantan Barat', 'Kalimantan', 'Pontianak'),
(21, 'Kalimantan Tengah', 'Kalimantan', 'Palangkaraya'),
(22, 'Kalimantan Selatan', 'Kalimantan', 'Banjarmasin'),
(23, 'Kalimantan Timur', 'Kalimantan', 'Samarinda'),
(24, 'Sulawesi Utara', 'Sulawesi', 'Manado'),
(25, 'Sulawesi Barat', 'Sulawesi', 'Kota Mamuju'),
(26, 'Sulawesi Tengah', 'Sulawesi', 'Palu'),
(27, 'Sulawesi Tenggara', 'Sulawesi', 'Kendari'),
(28, 'Sulawesi Selatan', 'Sulawesi', 'Makassar'),
(29, 'Gorontalo', 'Sulawesi', 'Gorontalo'),
(30, 'Maluku', 'Maluku', 'Ambon'),
(31, 'Maluku Utara', 'Maluku', 'Ternate'),
(32, 'Papua Barat', 'Papua', 'Kota Manokwari'),
(33, 'Papua', 'Papua', 'Jayapura'),
(34, 'Kepulauan Bangka Belitung', 'Kepulauan Bangka Belitung', '');

-- --------------------------------------------------------

--
-- Table structure for table `reset_pass`
--

CREATE TABLE IF NOT EXISTS `reset_pass` (
  `reset_id` int(11) NOT NULL,
  `reset_users` int(11) DEFAULT NULL,
  `reset_link` varchar(255) DEFAULT NULL,
  `reset_input` datetime DEFAULT NULL,
  `reset_expired` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('4be656c5aec00d2f64827a748f06f731', '::1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:42.0) Gecko/20100101 Firefox/42.0', 1447717516, 'a:1:{s:9:"user_data";s:0:"";}'),
('6e81b1718952520e8532fadd7c0d4d54', '::1', 'Mozilla/5.0 (X11; Linux x86_64; rv:30.0) Gecko/20100101 Firefox/30.0', 1407224038, ''),
('7ea20445fc0f8a3a0af19e90be8265f7', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.132 Safari/537.36', 1407223738, ''),
('86b4c92ee8a79960c66bc0a2eee70590', '192.168.8.128', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', 1407222519, 'a:3:{s:9:"user_data";s:0:"";s:5:"login";s:88:"RcammvlzkpjFXyUpgw6fB4CbjuKvS8G8EsjvSo+paeEM3hq209CnfcgkTb9v4DSGkvHJDJy0K743bbG/HOAw9w==";s:7:"user_id";s:88:"+/Y71/bsUWhQxcNBkGJAzo1i9n4LBAsqVNgAXMDA7Fp9xKjtVNzTJ4+PFJbhad81tG1iI8D5ouC/4mdMECOG1A==";}'),
('b6b482bef10b74d8841604e538abba9b', '127.0.0.1', 'Opera/9.80 (X11; Linux x86_64) Presto/2.12.388 Version/12.16', 1407141630, ''),
('ba674be91e24a6ab11c991705dc829b3', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.132 Safari/537.36', 1407140774, '');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE IF NOT EXISTS `setting` (
  `setting_id` int(11) NOT NULL,
  `setting_nama` char(128) DEFAULT NULL,
  `setting_value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`setting_id`, `setting_nama`, `setting_value`) VALUES
(1, 'web_judul', 'SPMB ONLINE'),
(2, 'sekolah_nama', 'AMIK MAHAPUTRA'),
(3, 'sekolah_alamat', 'Jalan Hr Soebrantas no 77 Kota Pekanbaru, Indonesia'),
(4, 'sekolah_telpon', '(0000) 123456'),
(5, 'sekolah_email', 'noreply@localhost.com');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE IF NOT EXISTS `siswa` (
  `siswa_id` int(11) NOT NULL,
  `siswa_gel` int(11) NOT NULL,
  `siswa_no_pendaftaran` int(8) NOT NULL,
  `siswa_nama` varchar(128) NOT NULL,
  `siswa_nama_panggilan` varchar(32) DEFAULT NULL,
  `siswa_jenis_kelamin` enum('l','p') DEFAULT 'l',
  `siswa_tempat_lahir` varchar(64) NOT NULL,
  `siswa_tanggal_lahir` date NOT NULL,
  `siswa_agama` int(11) DEFAULT NULL,
  `siswa_suku` varchar(64) DEFAULT NULL,
  `siswa_sekolah_asal` varchar(128) NOT NULL,
  `siswa_sekolah_alamat` varchar(255) DEFAULT NULL,
  `siswa_jumlah_saudara` int(2) DEFAULT NULL,
  `siswa_alamat` varchar(255) DEFAULT NULL,
  `siswa_prov` int(11) DEFAULT NULL,
  `siswa_kabupaten` varchar(64) DEFAULT NULL,
  `siswa_kecamatan` varchar(64) DEFAULT NULL,
  `siswa_kode_pos` char(16) DEFAULT NULL,
  `siswa_alamat_pos` varchar(255) DEFAULT NULL,
  `siswa_telepon` char(16) DEFAULT NULL,
  `siswa_hp` char(16) DEFAULT NULL,
  `siswa_email` varchar(128) DEFAULT NULL,
  `siswa_gol_darah` enum('none','a','b','ab','o') DEFAULT 'none',
  `siswa_anak_ke` int(2) DEFAULT NULL,
  `siswa_tinggi_badan` char(16) DEFAULT NULL,
  `siswa_berat_badan` char(16) DEFAULT NULL,
  `siswa_penyakit` varchar(255) DEFAULT NULL,
  `siswa_tanggal_daftar` date DEFAULT NULL,
  `siswa_status` enum('blm_dicek','sdh_dicek') NOT NULL DEFAULT 'blm_dicek',
  `siswa_ulang` enum('sudah','belum') DEFAULT 'belum',
  `siswa_tanggal_ulang` date DEFAULT NULL,
  `siswa_keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`siswa_id`, `siswa_gel`, `siswa_no_pendaftaran`, `siswa_nama`, `siswa_nama_panggilan`, `siswa_jenis_kelamin`, `siswa_tempat_lahir`, `siswa_tanggal_lahir`, `siswa_agama`, `siswa_suku`, `siswa_sekolah_asal`, `siswa_sekolah_alamat`, `siswa_jumlah_saudara`, `siswa_alamat`, `siswa_prov`, `siswa_kabupaten`, `siswa_kecamatan`, `siswa_kode_pos`, `siswa_alamat_pos`, `siswa_telepon`, `siswa_hp`, `siswa_email`, `siswa_gol_darah`, `siswa_anak_ke`, `siswa_tinggi_badan`, `siswa_berat_badan`, `siswa_penyakit`, `siswa_tanggal_daftar`, `siswa_status`, `siswa_ulang`, `siswa_tanggal_ulang`, `siswa_keterangan`) VALUES
(1, 6, 15010001, 'Mardianti', 'Dianti', 'p', 'Ujung Batu', '1992-12-03', 1, NULL, 'SMAN 9 PEKANBARU', NULL, NULL, NULL, 4, NULL, NULL, NULL, NULL, NULL, '085543635546', NULL, 'none', NULL, NULL, NULL, NULL, '2015-11-16', 'sdh_dicek', 'belum', '2015-11-16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE IF NOT EXISTS `test` (
  `test_id` int(11) NOT NULL,
  `test_siswa` int(11) DEFAULT NULL,
  `test_jentest` int(11) DEFAULT NULL,
  `test_nilai` decimal(5,2) DEFAULT '0.00'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`test_id`, `test_siswa`, `test_jentest`, `test_nilai`) VALUES
(2, 1, 2, '0.00'),
(3, 1, 3, '8.00'),
(4, 1, 4, '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL,
  `user_username` varchar(128) NOT NULL,
  `user_password` varchar(32) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_pangkat` enum('admin','user') NOT NULL DEFAULT 'user',
  `user_nama` varchar(128) DEFAULT NULL,
  `user_tanggal` date DEFAULT NULL,
  `user_keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_username`, `user_password`, `user_email`, `user_pangkat`, `user_nama`, `user_tanggal`, `user_keterangan`) VALUES
(1, 'admin', '0c7540eb7e65b553ec1ba6b20de79608', 'andhika.it09@gmail.com', 'admin', 'Andhika,S.Kom,M.Kom', '2015-11-17', 'Super Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agama`
--
ALTER TABLE `agama`
  ADD PRIMARY KEY (`agama_id`),
  ADD UNIQUE KEY `UNIQUE` (`agama_nama`);

--
-- Indexes for table `captcha`
--
ALTER TABLE `captcha`
  ADD PRIMARY KEY (`captcha_id`),
  ADD KEY `word` (`word`);

--
-- Indexes for table `gelombang`
--
ALTER TABLE `gelombang`
  ADD PRIMARY KEY (`gel_id`);

--
-- Indexes for table `jenis_test`
--
ALTER TABLE `jenis_test`
  ADD PRIMARY KEY (`jentest_id`),
  ADD UNIQUE KEY `UNIQUE` (`jentest_nama`,`jentest_gel`),
  ADD KEY `jentest_gel` (`jentest_gel`);

--
-- Indexes for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`jur_id`),
  ADD UNIQUE KEY `UNIQUE` (`jur_nama`);

--
-- Indexes for table `kuota`
--
ALTER TABLE `kuota`
  ADD PRIMARY KEY (`kuota_id`),
  ADD UNIQUE KEY `UNIQUE` (`kuota_gel`,`kuota_jur`),
  ADD KEY `kuota_jur` (`kuota_jur`);

--
-- Indexes for table `link`
--
ALTER TABLE `link`
  ADD KEY `link_id` (`link_id`);

--
-- Indexes for table `mata_pelajaran`
--
ALTER TABLE `mata_pelajaran`
  ADD PRIMARY KEY (`mapel_id`),
  ADD UNIQUE KEY `UNIQUE` (`mapel_nama`,`mapel_gel`),
  ADD KEY `mapel_gel` (`mapel_gel`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`nilai_id`),
  ADD UNIQUE KEY `UNIQUE` (`nilai_siswa`,`nilai_mapel`),
  ADD KEY `nilai_siswa` (`nilai_siswa`),
  ADD KEY `nilai_mapel` (`nilai_mapel`);

--
-- Indexes for table `orang_tua`
--
ALTER TABLE `orang_tua`
  ADD PRIMARY KEY (`ot_id`),
  ADD UNIQUE KEY `UNIQUE` (`ot_siswa`),
  ADD KEY `ot_siswa` (`ot_siswa`),
  ADD KEY `ot_pen_ayah` (`ot_pend_ayah`),
  ADD KEY `ot_pen_ibu` (`ot_pend_ibu`),
  ADD KEY `ot_pen_wali` (`ot_pend_wali`),
  ADD KEY `ot_pek_ayah` (`ot_pek_ayah`),
  ADD KEY `ot_pek_ibu` (`ot_pek_ibu`),
  ADD KEY `ot_pek_wali` (`ot_pek_wali`);

--
-- Indexes for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  ADD PRIMARY KEY (`pek_id`),
  ADD UNIQUE KEY `UNIQUE` (`pek_nama`);

--
-- Indexes for table `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`pend_id`),
  ADD UNIQUE KEY `UNIQUE` (`pend_nama`);

--
-- Indexes for table `pilihan`
--
ALTER TABLE `pilihan`
  ADD PRIMARY KEY (`pilihan_id`),
  ADD UNIQUE KEY `UNIQUE` (`pilihan_siswa`,`pilihan_ke`),
  ADD KEY `pilihan_siswa` (`pilihan_siswa`),
  ADD KEY `pilihan_jur` (`pilihan_jur`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD KEY `post_id` (`post_id`),
  ADD KEY `post_user` (`post_user`);

--
-- Indexes for table `prestasi`
--
ALTER TABLE `prestasi`
  ADD PRIMARY KEY (`prestasi_id`),
  ADD KEY `prestasi_siswa` (`prestasi_siswa`);

--
-- Indexes for table `provinsi`
--
ALTER TABLE `provinsi`
  ADD PRIMARY KEY (`prov_id`),
  ADD UNIQUE KEY `UNIQUE` (`prov_nama`);

--
-- Indexes for table `reset_pass`
--
ALTER TABLE `reset_pass`
  ADD KEY `reset_id` (`reset_id`),
  ADD KEY `reset_users` (`reset_users`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `last_activity_idx` (`last_activity`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD UNIQUE KEY `UNIQUE` (`setting_nama`),
  ADD KEY `setting_id` (`setting_id`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`siswa_id`),
  ADD UNIQUE KEY `UNIQUE` (`siswa_no_pendaftaran`),
  ADD KEY `siswa_agama` (`siswa_agama`),
  ADD KEY `siswa_suku` (`siswa_suku`),
  ADD KEY `siswa_prov` (`siswa_prov`),
  ADD KEY `siswa_gel` (`siswa_gel`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`test_id`),
  ADD UNIQUE KEY `UNIQUE` (`test_siswa`,`test_jentest`),
  ADD KEY `test_siswa` (`test_siswa`),
  ADD KEY `test_jenis` (`test_jentest`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `UNIQUE` (`user_username`,`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agama`
--
ALTER TABLE `agama`
  MODIFY `agama_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `captcha`
--
ALTER TABLE `captcha`
  MODIFY `captcha_id` bigint(13) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `gelombang`
--
ALTER TABLE `gelombang`
  MODIFY `gel_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `jenis_test`
--
ALTER TABLE `jenis_test`
  MODIFY `jentest_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `jur_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `kuota`
--
ALTER TABLE `kuota`
  MODIFY `kuota_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `link`
--
ALTER TABLE `link`
  MODIFY `link_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `mata_pelajaran`
--
ALTER TABLE `mata_pelajaran`
  MODIFY `mapel_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `nilai`
--
ALTER TABLE `nilai`
  MODIFY `nilai_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `orang_tua`
--
ALTER TABLE `orang_tua`
  MODIFY `ot_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  MODIFY `pek_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `pendidikan`
--
ALTER TABLE `pendidikan`
  MODIFY `pend_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pilihan`
--
ALTER TABLE `pilihan`
  MODIFY `pilihan_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `prestasi`
--
ALTER TABLE `prestasi`
  MODIFY `prestasi_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `provinsi`
--
ALTER TABLE `provinsi`
  MODIFY `prov_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `reset_pass`
--
ALTER TABLE `reset_pass`
  MODIFY `reset_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `siswa_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `test_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `jenis_test`
--
ALTER TABLE `jenis_test`
  ADD CONSTRAINT `jentest_gel` FOREIGN KEY (`jentest_gel`) REFERENCES `gelombang` (`gel_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `kuota`
--
ALTER TABLE `kuota`
  ADD CONSTRAINT `kuota_gel` FOREIGN KEY (`kuota_gel`) REFERENCES `gelombang` (`gel_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `kuota_jur` FOREIGN KEY (`kuota_jur`) REFERENCES `jurusan` (`jur_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mata_pelajaran`
--
ALTER TABLE `mata_pelajaran`
  ADD CONSTRAINT `mapel_gel` FOREIGN KEY (`mapel_gel`) REFERENCES `gelombang` (`gel_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nilai`
--
ALTER TABLE `nilai`
  ADD CONSTRAINT `nilai_mapel` FOREIGN KEY (`nilai_mapel`) REFERENCES `mata_pelajaran` (`mapel_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `nilai_siswa` FOREIGN KEY (`nilai_siswa`) REFERENCES `siswa` (`siswa_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orang_tua`
--
ALTER TABLE `orang_tua`
  ADD CONSTRAINT `ot_pek_ayah` FOREIGN KEY (`ot_pek_ayah`) REFERENCES `pekerjaan` (`pek_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ot_pek_ibu` FOREIGN KEY (`ot_pek_ibu`) REFERENCES `pekerjaan` (`pek_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ot_pek_wali` FOREIGN KEY (`ot_pek_wali`) REFERENCES `pekerjaan` (`pek_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ot_pen_ayah` FOREIGN KEY (`ot_pend_ayah`) REFERENCES `pendidikan` (`pend_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ot_pen_ibu` FOREIGN KEY (`ot_pend_ibu`) REFERENCES `pendidikan` (`pend_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ot_pen_wali` FOREIGN KEY (`ot_pend_wali`) REFERENCES `pendidikan` (`pend_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `ot_siswa` FOREIGN KEY (`ot_siswa`) REFERENCES `siswa` (`siswa_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pilihan`
--
ALTER TABLE `pilihan`
  ADD CONSTRAINT `pilihan_jur` FOREIGN KEY (`pilihan_jur`) REFERENCES `jurusan` (`jur_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `pilihan_siswa` FOREIGN KEY (`pilihan_siswa`) REFERENCES `siswa` (`siswa_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `post_user` FOREIGN KEY (`post_user`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `prestasi`
--
ALTER TABLE `prestasi`
  ADD CONSTRAINT `prestasi_siswa` FOREIGN KEY (`prestasi_siswa`) REFERENCES `siswa` (`siswa_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reset_pass`
--
ALTER TABLE `reset_pass`
  ADD CONSTRAINT `reset_users` FOREIGN KEY (`reset_users`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `siswa`
--
ALTER TABLE `siswa`
  ADD CONSTRAINT `siswa_agama` FOREIGN KEY (`siswa_agama`) REFERENCES `agama` (`agama_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `siswa_gel` FOREIGN KEY (`siswa_gel`) REFERENCES `gelombang` (`gel_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `siswa_prov` FOREIGN KEY (`siswa_prov`) REFERENCES `provinsi` (`prov_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `test`
--
ALTER TABLE `test`
  ADD CONSTRAINT `test_jenis` FOREIGN KEY (`test_jentest`) REFERENCES `jenis_test` (`jentest_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `test_siswa` FOREIGN KEY (`test_siswa`) REFERENCES `siswa` (`siswa_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
