<?php 
session_start();
include "config/koneksi.php";
# Baca variabel Form (If Register Global ON)
$TxtUser 	= $_REQUEST['TxtUser'];
$TxtPassword = $_REQUEST['TxtPassword2'];

	# Validasi Form
	if (trim($TxtUser)=="") {
		include "formloginuser.php";
		echo "Username belum diisi, ulangi kembali";
	}
	elseif (trim($TxtPassword)=="") {
		include "formloginuser.php";
		echo "Password masih kosong, ulangi kembali";
	}

else {
	//cek user di databse
	$strquery="select * from tb_user where user='".$TxtUser."' && password='".$TxtPassword."'";
	$query=mysql_query($strquery,$koneksi);
	$cekData=mysql_num_rows($query);
	if($cekData>=1){
		
	$result=mysql_fetch_array($query);
	$userID=$result['id_user'];
	$userNama=$result['nama'];
	$userUmur=$result['umur'];
	$userAlamat=$result['alamat'];
	$userEmail=$result['email'];
	$_SESSION['userID']=$userID;
	
	$sqldel = "DELETE FROM tb_temp_pembeli WHERE id_user='".$userID."'";
	mysql_query($sqldel, $koneksi);
	
	$sql  = " INSERT INTO tb_temp_pembeli (id_user,nama,umur,alamat,email,waktu) 
		 	  VALUES ('$userID','$userNama','$userUmur','$userAlamat','$userEmail',NOW())";
	mysql_query($sql, $koneksi) 
		  or die ("SQL Error 2".mysql_error());
	
	//$sqlhapus = "DELETE FROM tb_temp_penyakit WHERE id_user='".$userID."'";
//	mysql_query($sqlhapus, $koneksi) 
//			or die ("SQL Error 1".mysql_error());
			
			$sqlhapus2 = "DELETE FROM tb_hasil_analisa WHERE id_user='".$userID."'";
	mysql_query($sqlhapus2, $koneksi) 
			or die ("SQL Error 2".mysql_error());
			
			$sqlhapus3 = "DELETE FROM tb_temp WHERE id_user='" .$userID."'";
	mysql_query($sqlhapus3, $koneksi) 
			or die ("SQL Error 3".mysql_error());
			
	echo "<meta http-equiv='refresh' content='0; url=index.php?page=konsul'>";
	//////////
	}else{
	include "formloginuser.php";
		echo "Username dan password salah!";
}
	
}

//mysql_close($conn);
?>