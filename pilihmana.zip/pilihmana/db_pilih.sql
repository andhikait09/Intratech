CREATE TABLE tb_admin (
  id_admin int(11) NOT NULL AUTO_INCREMENT,
  nama_admin varchar(50) NOT NULL,
  password varchar(30) NOT NULL,
  PRIMARY KEY (id_admin)
) ENGINE=MyISAM;

INSERT INTO `tb_admin` (`id_admin`, `nama_admin`, `password`) VALUES
(1, 'admin', 'admin');

CREATE TABLE tb_gejala (
  id_gejala int(11) NOT NULL AUTO_INCREMENT,
  nama_gejala varchar(50) NOT NULL,
  PRIMARY KEY (id_gejala)
) ENGINE=MyISAM;

INSERT INTO `tb_gejala` (`id_gejala`, `nama_gejala`) VALUES
(1, 'Garansi resmi nasional 1 tahun');

CREATE TABLE tb_hasil_analisa (
  id_analisa int(11) NOT NULL AUTO_INCREMENT,
  id_user int(11) NOT NULL,
  nama varchar(100) NOT NULL,
  umur varchar(3) NOT NULL,
  alamat text NOT NULL,
  email varchar(100) NOT NULL,
  id_laptop varchar(7) NOT NULL,
  waktu datetime NOT NULL,
  persentase varchar(3) NOT NULL,
  PRIMARY KEY (id_analisa),
  KEY id_laptop (id_laptop)
) ENGINE=MyISAM;

CREATE TABLE tb_komentar (
  id_komentar int(11) NOT NULL AUTO_INCREMENT,
  nama varchar(50) NOT NULL,
  email varchar(100) NOT NULL,
  komentar text NOT NULL,
  waktu datetime NOT NULL,
  PRIMARY KEY (id_komentar)
) ENGINE=MyISAM;

CREATE TABLE tb_laptop (
  id_laptop char(7) NOT NULL,
  nama_laptop varchar(150) NOT NULL,
  keterangan text NOT NULL,
  solusi text NOT NULL,
  PRIMARY KEY (id_laptop)
) ENGINE=InnoDB;

INSERT INTO `tb_laptop` (`id_laptop`, `nama_laptop`, `keterangan`, `solusi`) VALUES
('P000001', 'Acer', 'xx', 'Office');

CREATE TABLE tb_report_login (
  no_log int(11) NOT NULL AUTO_INCREMENT,
  id_user int(11) NOT NULL,
  nama varchar(100) NOT NULL,
  hasil_analisa varchar(50) NOT NULL,
  waktu_akses datetime NOT NULL,
  PRIMARY KEY (no_log)
) ENGINE=MyISAM;

CREATE TABLE tb_rule (
  no_rule int(11) NOT NULL AUTO_INCREMENT,
  id_gejala int(11) NOT NULL,
  id_laptop char(7) NOT NULL,
  PRIMARY KEY (no_rule),
  KEY id_gejala (id_gejala),
  KEY id_laptop (id_laptop)
) ENGINE=MyISAM;

INSERT INTO `tb_rule` (`no_rule`, `id_gejala`, `id_laptop`) VALUES
(1, 1, 'P000001');

CREATE TABLE tb_temp (
  no_temp int(11) NOT NULL AUTO_INCREMENT,
  id_gejala int(11) NOT NULL,
  jawaban varchar(5) NOT NULL,
  id_user int(11) NOT NULL,
  PRIMARY KEY (no_temp),
  KEY id_gejala (id_gejala)
) ENGINE=MyISAM;

CREATE TABLE tb_temp_analisa (
  no_temp_analisa int(11) NOT NULL AUTO_INCREMENT,
  id_user int(11) NOT NULL,
  id_laptop char(7) NOT NULL,
  id_gejala int(11) NOT NULL,
  status enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (no_temp_analisa),
  KEY id_gejala (id_gejala)
) ENGINE=MyISAM;

CREATE TABLE tb_temp_gejala (
  no_temp_gejala int(11) NOT NULL AUTO_INCREMENT,
  id_gejala int(11) NOT NULL,
  id_user int(11) NOT NULL,
  PRIMARY KEY (no_temp_gejala)
) ENGINE=MyISAM;

CREATE TABLE tb_temp_pembeli (
  id_pembeli int(11) NOT NULL AUTO_INCREMENT,
  id_user varchar(7) NOT NULL,
  nama varchar(100) NOT NULL,
  umur varchar(3) NOT NULL,
  alamat text NOT NULL,
  email varchar(100) NOT NULL,
  waktu datetime NOT NULL,
  PRIMARY KEY (id_pembeli)
) ENGINE=MyISAM;

CREATE TABLE tb_temp_laptop (
  no_temp_laptop int(11) NOT NULL AUTO_INCREMENT,
  id_laptop char(7) NOT NULL,
  id_user int(11) NOT NULL,
  PRIMARY KEY (no_temp_laptop)
) ENGINE=MyISAM;

CREATE TABLE tb_user (
  id_user int(11) NOT NULL AUTO_INCREMENT,
  nama varchar(100) NOT NULL,
  umur varchar(3) NOT NULL,
  alamat text NOT NULL,
  email varchar(100) NOT NULL,
  user varchar(50) NOT NULL,
  password varchar(50) NOT NULL,
  PRIMARY KEY (id_user)
) ENGINE=MyISAM;

INSERT INTO `tb_user` (`id_user`, `nama`, `umur`, `alamat`, `email`, `user`, `password`) VALUES
(1, 'aa', 'aa', 'aa', 'aa', 'aa', 'aa');

