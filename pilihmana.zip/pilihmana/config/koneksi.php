<?php
error_reporting(0);
$host	= "localhost";
$user	= "root";
$pass	= "";
$db	= "db_pilih";

$koneksi	= mysql_connect("localhost","root","");
if (! $koneksi) {
  echo "Koneksi gagal";
  mysql_error();
}
mysql_select_db($db)
	 or die ("Database tidak ada".mysql_error());

?>