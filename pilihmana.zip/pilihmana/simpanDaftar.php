<?php 
//include "session.php"; 
include "config/koneksi.php";
	
# Baca variabel Form (If Register Global ON)

$TxtNama 	= $_REQUEST['TxtNama'];
$TxtUmur=$_REQUEST['TxtUmur'];
$TxtAlamat=$_REQUEST['TxtAlamat'];
$txtEmail=$_REQUEST['TxtEmail'];
$txtUsername=$_REQUEST['TxtUsername'];
$txtPassword=$_REQUEST['TxtPassword'];

# Validasi Form
if (trim($TxtNama)=="") {
	echo "Nama masih kosong, ulangi kembali";
	include "formdaftaruser.php";
}elseif(trim($TxtUmur)==""){
	echo "Umur masih kosong, ulangi kembali";
	include "formdaftaruser.php";
}elseif(trim($TxtAlamat)==""){
	echo "Alamat masih kosong, ulangi kembali";
	include "formdaftaruser.php";
}elseif(trim($txtEmail)==""){
echo "Email masih kosong, ulangi kembali";
	include "formdaftaruser.php";	
}elseif(trim($txtUsername)==""){
echo "Username masih kosong, ulangi kembali";
	include "formdaftaruser.php";	
}elseif(trim($txtPassword)==""){
echo "Password masih kosong, ulangi kembali";
	include "formdaftaruser.php";	
}

else {
	$sql  = " INSERT INTO tb_user (nama,umur,alamat,email,user,password) VALUES ('$TxtNama','$TxtUmur','$TxtAlamat','$txtEmail','$txtUsername','$txtPassword')";
	mysql_query($sql, $koneksi) 
		  or die ("SQL Error".mysql_error());

	$pesan= "Data berhasil disimpan";
	//header("Location:"?page=konsul");
	echo "<meta http-equiv='refresh' content='0; url=index.php?page=login'>";
}
?>
