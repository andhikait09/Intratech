<?php 
include "session.php"; 
include "menu.php"; 
include "../config/koneksi.php";
?>
<html>
<head>
<title>Tampilan Data laptop</title>
</head>
<body>
<div align="center">
  <table width="100%" border="0" cellpadding="2" cellspacing="1" bgcolor="#DBEAF5">
    <tr> 
      <td colspan="4" bgcolor="#DBEAF5" align="center"><b>DAFTAR SEMUA LAPTOP</b></td>
    </tr>
    <tr> 
      <td width="23"><b>No</b></td>
      <td width="164"><b>Nama laptop</b></td>
      <td width="200"><b>Keterangan </b></td>
      <td width="92" align="center"><b>Pilihan</b></td>
    </tr>
    <?php 
	$sql = "SELECT * FROM tb_laptop ORDER BY id_laptop";
	$qry = mysql_query($sql, $koneksi) 
		 or die ("SQL Error".mysql_error());
	while ($data=mysql_fetch_array($qry)) {
	$no++;
  ?>
    <tr bgcolor="#FFFFFF"> 
      <td><?php echo $no; ?></td>
      <td><?php echo $data['nama_laptop']; ?></td>
      <td><?php echo $data['keterangan']; ?></td>
      <td align="center"> 
        <a href="editlaptop.php?kdubah=<?php echo $data['id_laptop']; ?>" target="_self">Ubah</a> 
        | <a href="hapuslaptop.php?kdhapus=<?php echo $data['id_laptop']; ?>" target="_self">Hapus</a></td>
    </tr>
    <?php
  }
  ?>
    <tr bgcolor="#FFFFFF"> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td align="center"><a href="formlaptop.php">Tambah</a></td>
    </tr>
  </table>
</div>
</body>
</html>
