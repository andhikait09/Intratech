<?php
session_start();
include_once "../config/koneksi.php";

$TxtUser   = $_REQUEST['TxtUser'];
$TxtPasswd = $_REQUEST['TxtPasswd'];

if (trim($TxtUser)=="") {
	echo "DATA USER BELUM DIISI";
	include "Login.php"; exit;
}
elseif (trim($TxtPasswd)=="") {
	echo "DATA PASSWORD BELUM DIISI";
	include "Login.php"; exit;
}

$sql_cek = "SELECT * FROM tb_admin WHERE nama_admin='$TxtUser' 
		    AND password='$TxtPasswd'";
$qry_cek = mysql_query($sql_cek, $koneksi) 
		   or die ("Gagal Cek".mysql_error());
$ada_cek = mysql_num_rows($qry_cek);
if ($ada_cek >=1) {
	$SES_USER=$TxtUser;
	$_SESSION['SES_USER']=$SES_USER;
	
	header ("location: index.php");
	exit;
}
else {
	echo "USER DAN PASSWORD TIDAK SESUAI";
	include "Login.php"; 
	exit;
}
?>
 