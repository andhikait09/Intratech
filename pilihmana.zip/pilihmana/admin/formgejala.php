<?php 
include "session.php"; 
include "menu.php"; 
include "../config/koneksi.php";

?>
<html>
<head>
<title>Masukan Data Parameter</title>
</head>
<body>
<form name="form1" method="post" action="simpangejala.php">
  <div align="center">
    <table width="400" border="0" cellpadding="2" cellspacing="1" bgcolor="#DBEAF5">
      <tr> 
        <td colspan="2" bgcolor="#DBEAF5"><b>MASUKAN PARAMETER</b></td>
      </tr>
      <tr bgcolor="#FFFFFF"> 
        <td>Kode</td>
        <td><input name="TxtKode" type="text"  maxlength="4" size="6" value="Auto" disabled="disabled"></td>
      </tr>
      <tr bgcolor="#FFFFFF"> 
        <td width="77">Parameter</td>
        <td width="361"><textarea name="TxtGejala" cols="35" rows="3"></textarea></td>
      </tr>
      <tr bgcolor="#FFFFFF"> 
        <td>&nbsp;</td>
        <td><input type="submit" name="Submit" value="Simpan"></td>
      </tr>
    </table>
  </div>
</form>
</body>
</html>
