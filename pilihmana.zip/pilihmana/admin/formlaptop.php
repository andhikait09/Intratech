<?php 
include "session.php"; 
include "menu.php"; 
include "../config/koneksi.php";
include "../config/kodeauto.php";
?>
<html>
<head>
<title>Masukan Data laptop</title>
</head>

<body>
<form name="form1" method="post" action="simpanlaptop.php">
  <div align="center">
    <table width="450" border="0" cellpadding="2" cellspacing="1" bgcolor="#DBEAF5">
      <tr> 
        <td colspan="2" bgcolor="#DBEAF5"><b>MASUKAN DATA LAPTOP</b></td>
    </tr>
      <tr bgcolor="#FFFFFF"> 
        <td>Kode</td>
      <td><input name="TxtKode" type="text"  value="<?php echo kdauto("tb_laptop","P"); ?>" size="10" disabled="disabled" >
        <input name="TxtKodeH" type="hidden" value="<?php echo kdauto("tb_laptop","P"); ?>"></td>
    </tr>
      <tr bgcolor="#FFFFFF"> 
        <td width="77">laptop</td>
      <td width="361"><input name="Txtlaptop" type="text" value="<?php $TxtPenyakit; ?>" size="45" maxlength="100"></td>
    </tr>
       <tr bgcolor="#FFFFFF">
        <td>Keterangan</td>
      <td><textarea name="TxtKeterangan" cols="40" value="<?php $TxtKeterangan; ?>" rows="4"></textarea></td>
    </tr>
      <tr bgcolor="#FFFFFF">
        <td>Solusi</td>
      <td><textarea name="TxtSolusi" cols="40" value="<?php $TxtSolusi; ?>" rows="4"></textarea></td>
    </tr>
      <tr bgcolor="#FFFFFF"> 
        <td>&nbsp;</td>
      <td><input type="submit" name="Submit" value="Simpan"></td>
    </tr>
    </table>
  </div>
</form>
</body>
</html>
