<?php 
include "session.php"; 
include "menu.php"; 
include "../config/koneksi.php";
?>
<html>
<head>
<title>Tampilan Data laptop</title>
</head>
<body>
<div align="center">
  <table width="500" border="0" cellpadding="2" cellspacing="1" bgcolor="#DBEAF5">
    <tr> 
      <td colspan="2" align="center"><b>DAFTAR SEMUA LAPTOP</b></td>
    </tr>
    <tr bgcolor="#DBEAF5"> 
      <td colspan="2">&nbsp;</td>
    </tr>
    <?php 
	$sql = "SELECT * FROM tb_laptop ORDER BY id_laptop";
	$qry = mysql_query($sql, $koneksi) 
		 or die ("SQL Error".mysql_error());
	while ($data=mysql_fetch_array($qry)) {
	$no++;
  ?>
    <tr bgcolor="#FFFFFF">
      <td width="110">Kode</td>
      <td width="379"><?php echo $data['id_laptop']; ?></td>
    </tr>
    <tr bgcolor="#FFFFFF">
      <td valign="top">Nama laptop </td>
      <td><?php echo $data['nama_laptop']; ?></td>
    </tr>
    <tr bgcolor="#FFFFFF">
      <td valign="top">Keterangan</td>
      <td><?php echo $data['keterangan']; ?></td>
    </tr>
    <tr bgcolor="#FFFFFF"> 
      <td valign="top">Solusi</td>
      <td><?php echo $data['solusi']; ?></td>
    </tr>
    <tr bgcolor="#DBEAF5"> 
      <td colspan="2">&nbsp;</td>
    </tr>
    <?php
  }
  ?>
  </table>
</div>
</body>
</html>
