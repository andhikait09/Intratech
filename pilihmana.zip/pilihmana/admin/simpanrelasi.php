<?php 
include "session.php"; 
include "../config/koneksi.php";

#Baca Variabel Form
$TxtKodeH  = $_REQUEST['Cmblaptop'];
//$TxtPebyakit=$_REQUEST['CmbPenyakit'];

$CekGejala = $_REQUEST['CekGejala'];

#Validasi Form
if (trim($TxtKodeH)=="") {
	//$jum = count($CekGejala);
	//echo "$jum";
	echo "Nama laptop belum dipilih, ulangi kembali";
	include "formrelasi.php";
	}
else {
	$jum = count($CekGejala);
	if ($jum==0) {
	//echo "$CekGejala";
	echo "BELUM ADA GEJALA YANG DIPILIH";
	}
	else {
	
	
///////////////////////////////////////////////////////////////////
	#Untuk menghapus yang tidak dipilih lagi
		//kode mendata relasi
	$sqlpil = "SELECT * FROM tb_rule WHERE id_laptop='$TxtKodeH'";
		$qrypil = mysql_query($sqlpil);
		while ($datapil=mysql_fetch_array($qrypil)){
	//kode untuk mengurangi gejala yang dipilih
		for ($i = 0; $i < $jum; ++$i) {
	//perintah untuk menghapus relasi
		if ($datapil['id_gejala'] != $CekGejala[$i]) {
			$sqldel = "DELETE FROM tb_rule WHERE id_laptop='$TxtKodeH' AND NOT id_gejala IN ('CekGejala[$i]')";
			mysql_query($sqldel,$koneksi);
			}
			}
		}
		#Untuk Gejala Tambahan
	for ($i = 0; $i < $jum; $i++) {
		// perintah untuk mendapatkan relasi
		$sqlr = "SELECT * FROM tb_rule WHERE id_laptop='$TxtKodeH' AND id_gejala='$CekGejala[$i]'";
		$qryr = mysql_query($sqlr, $koneksi);
		$cocok = mysql_num_rows ($qryr) ;
			// Gejala baru yang akan disimpan
		if (! $cocok==1) {
		$sql = "INSERT INTO tb_rule (id_laptop,id_gejala) values ('$TxtKodeH','$CekGejala[$i]')";
		mysql_query($sql, $koneksi)
			or die ("SQL Input Relasi Gagal" .mysql_error() );
			}
		}
		//pesan sebagai konfirmasi
	$pesan = "SUKSES DISIMPAN";
	header("Location: formrelasi.php?kdsakit=$TxtKodeH&info=$pesan");
		}
	}
	?>
