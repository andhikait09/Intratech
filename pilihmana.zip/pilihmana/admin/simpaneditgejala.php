<?php 
include "session.php"; 
include "../config/koneksi.php";
	
# Baca variabel Form (If Register Global ON)
$TxtKodeH 	= $_REQUEST['TxtKodeH'];
$TxtGejala 	= $_REQUEST['TxtGejala'];

#validasi form na
if (trim($TxtKodeH)=="") {
	echo "Kode Belum Terbentuk, Silahkan Ulangi Lagi";
	include "editgejala.php";
	}
elseif (trim($TxtGejala)==""){
	echo "Gejala Masih Kosong, Silahkan Ulangi Kembali";
	include "editgejala.php";
} 
else {
	$sql = "UPDATE tb_gejala SET nama_gejala='$TxtGejala' ";
	$sql .= " WHERE id_gejala='$TxtKodeH'";
	mysql_query($sql, $koneksi)
		or die ("SQL Error".mysql_error());
		
	echo "DATA TELAH BERHASIL DIUBAH";
	include "tampilgejala.php";
	}

?>