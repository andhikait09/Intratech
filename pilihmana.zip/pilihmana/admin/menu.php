<style type="text/css">
<!--
body {
	background-image: url();
	background-repeat: no-repeat;
	background-color: #FFFFFF;
}
-->
</style>
<div align="center"><strong>[ <a href="tampillaptop.php" target="_self">Input laptop</a> 
  | <a href="tampilgejala.php" target="_self">Input Parameter</a> 
  | <a href="formrelasi.php" target="_self">Input Relasi</a> ] 
  
  [ <a href="tampillaptop.php" target="_self">Ubah laptop</a> 
  | <a href="tampilgejala.php" target="_self">Ubah Parameter </a>] 
  [ <a href="laporanlaptop.php" target="_self">Lap laptop</a> 
  | <a href="laporangejala.php" target="_self">Lap Parameter</a> ] 
  [ <a href="logout.php" target="_self">Logout</a> ]</strong></div>
<div align="center"><br />
  <br />
  <br />
</div>
