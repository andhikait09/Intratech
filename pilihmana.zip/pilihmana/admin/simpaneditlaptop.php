<?php 
include "session.php"; 
include "../config/koneksi.php";
	
# Baca variabel Form (If Register Global ON)
$TxtKodeH 	 = $_REQUEST['TxtKodeH'];
$Txtlaptop = $_REQUEST['Txtlaptop'];
$TxtKeterangan = $_REQUEST['TxtKeterangan'];
$TxtSolusi   = $_REQUEST['TxtSolusi'];

#validasi FORM
if (trim($TxtKodeH)=="") {
	echo"Kode Tidak Ada , Silahkan Ulangi Kembali";
	include "editlaptop.php";
}
elseif (trim($Txtlaptop)=="")  {
	echo "Nama laptop Masih Kosong, Ulangi kembali";
	include "editlaptop.php";
	}
elseif (trim($TxtKeterangan)=="") {
	echo "Keterangan Masih Kosong , Silahkan ulangi Kembali";
	include "editlaptop.php";
	}
elseif (trim($TxtSolusi)=="") {
	echo "Solusi Masih Kosong , Silahkan Ulangi Kembali";
	include "editlaptop.php";
	}
else {
//Sql simpan perubahan
$sql = " UPDATE tb_laptop SET
	nama_laptop='$TxtPenyakit',
	keterangan='$TxtKeterangan',
	solusi='$TxtSolusi'
		WHERE id_laptop='$TxtKodeH'";
mysql_query($sql, $koneksi)
	or die ("SQL ERROR" .mysql_error());
	
	echo "DATA TELAH BERHASIL DIUBAH";
	include "tampillaptop.php";
	}
?>
