<?php 
include "session.php"; 
include "../config/koneksi.php";
	
# Baca variabel Form (If Register Global ON)
$TxtKodeH 	 	= $_POST['TxtKodeH'];
$Txtlaptop 		= $_POST['Txtlaptop'];
$TxtKeterangan 	= $_POST['TxtKeterangan'];
$TxtSolusi   	= $_POST['TxtSolusi'];

# Validasi Form
if (trim($TxtKodeH)=="") {
	echo "Kode belum terbentuk, ulangi kembali";
	include "formlaptop.php";
}
elseif (trim($Txtlaptop)=="") {
	echo "Nama laptop masih kosong, ulangi kembali";
	include "formlaptop.php";
}
elseif (trim($TxtKeterangan)=="") {
	echo "Keterangan masih kosong, ulangi kembali";
	include "formlaptop.php";
}
elseif (trim($TxtSolusi)=="") {
	echo "Solusi masih kosong, ulangi kembali";
	include "formlaptop.php";
}
else {
	$sql  = " INSERT INTO tb_laptop (id_laptop,nama_laptop,keterangan,solusi) VALUES ('$TxtKodeH','$Txtlaptop','$TxtKeterangan','$TxtSolusi')";
	mysql_query($sql, $koneksi) or die ("SQL Error".mysql_error());

	$pesan= "DATA TELAH BERHASIL DISIMPAN";
	header("Location: formlaptop.php?pesan=$pesan");
}
?>
