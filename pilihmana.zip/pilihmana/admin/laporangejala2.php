<?php 
include "session.php"; 
include "menu.php"; 
include "../config/koneksi.php";

$kdsakit = $_REQUEST['Cmblaptop'];
$sqlp = "SELECT * FROM tb_laptop WHERE id_laptop='$kdsakit' ";
$qryp = mysql_query($sqlp);
$datap= mysql_fetch_array($qryp);
$sakit = $datap['nama_laptop'];
?>
<html>
<head>
<title>Tampilan Data Parameter laptop</title>
</head>
<body>
<b>NAMA LAPTOP : <?php $sakit; ?> </b>
<table width="400" border="0" cellpadding="2" cellspacing="1" bgcolor="#ffffff">
  <tr> 
    <td colspan="3" bgcolor="#DBEAF5" align="center"><b>DAFTAR PARAMETER</b></td>
  </tr>
  <tr bgcolor="#DBEAF5"> 
    <td width="21" align="center"><b>No</b></td>
    <td width="47"><b>Kode</b></td>
    <td width="316" bgcolor="#DBEAF5"><b>Nama Parameter</b></td>
  </tr>
  <?php 
	$sqlg  = "SELECT tb_gejala.* FROM tb_gejala,tb_rule ";
	$sqlg .= "WHERE tb_gejala.id_gejala=tb_rule.id_gejala ";
	$sqlg .= "AND  tb_rule.id_laptop='$kdsakit' ";
	$sqlg .= "ORDER BY tb_gejala.id_gejala";
	$qryg = mysql_query($sqlg, $koneksi) 
		 or die ("SQL Error".mysql_error());
	while ($datag=mysql_fetch_array($qryg)) {
	$no++;
  ?>
  <tr bgcolor="#FFFFFF"> 
    <td align="center"><?php echo $no; ?></td>
    <td><?php echo $datag['id_gejala']; ?></td>
    <td><?php echo $datag['nama_gejala']; ?></td>
  </tr>
  <?php
  }
  ?>
  <tr> 
    <td colspan="3" bgcolor="#DBEAF5">&nbsp;</td>
  </tr>
</table>
 </body>
</html>
