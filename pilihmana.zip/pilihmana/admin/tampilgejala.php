<?php 
include "session.php"; 
include "menu.php";
include "../config/koneksi.php";
?>
<html>
<head>
<title>Tampilan Data Parameter</title>
</head>
<body>
<div align="center">
  <table width="100%" border="0" cellpadding="2" cellspacing="1" bgcolor="#DBEAF5">
    <tr bgcolor="#33FFFF"> 
      <td colspan="3" bgcolor="#ffffff" align="center"><b>DAFTAR SEMUA PARAMETER</b></td>
    </tr>
    <tr> 
      <td width="24"><b>No</b></td>
      <td width="315"><b>Nama Parameter</b></td>
      <td width="95" align="center"><b>Pilihan</b></td>
    </tr>
    <?php 
	$sql = "SELECT * FROM tb_gejala ORDER BY id_gejala";
	$qry = mysql_query($sql, $koneksi) 
		 or die ("SQL Error".mysql_error());
	while ($data=mysql_fetch_array($qry)) {
	$no++;
  ?>
    <tr bgcolor="#FFFFFF"> 
      <td><?php echo $no; ?></td>
      <td><?php echo $data['nama_gejala']; ?></td>
      <td align="center"> 
        <a href="editgejala.php?kdubah=<?php echo $data['id_gejala']; ?>" target="_self">Ubah</a> 
        | <a href="hapusgejala.php?kdhapus=<?php echo $data['id_gejala']; ?>" target="_self">Hapus</a></td>
    </tr>
    <?php
  }
  ?>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td align="center"><a href="formgejala.php">Tambah</a></td>
    </tr>
  </table>
</div>
</body>
</html>
