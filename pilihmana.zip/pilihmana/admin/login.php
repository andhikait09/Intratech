<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login Admin</title>
<link href="stylelog.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form action="ceklogin.php" method="post" name="form1" target="_self">
<div id="layer01_holder">
  <div id="left"></div>
  <div id="center"></div>
  <div id="right"></div>
</div>

<div id="layer02_holder">
  <div id="left"></div>
  <div id="center"></div>
  <div id="right"></div>
</div>

<div id="layer03_holder">
  <div id="left"></div>
  <div id="center">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><div align="center">Administrator Login Page<br />
          <br />
    </div></td>
  </tr>
  <tr>
    <td><form id="form1" name="form1" method="post" action="">
      <label>Username 
      <input name="TxtUser" type="text" id="textfield" />
      </label>
      <label>Password
      <input type="password" name="TxtPasswd" id="textfield2" style="margin-top:5px;" />
      </label>
      <label>
       <input type="submit" name="button" id="button" value="Login" />
      </label>
    </form>    </td>
  </tr>
</table>
  </div>
  <div id="right"></div>
</div>

<div id="layer04_holder">
  <div id="left"></div>
  <div id="center">
    <div align="center">PilihMana</a></div>
  </div>
  <div id="right"></div>
</div>

<div id="layer05_holder">  
  <div align="left">Copyright ©2019</div>
</div>
</body>
</html>