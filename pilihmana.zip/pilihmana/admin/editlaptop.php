<?php 
include "session.php"; 
include "menu.php"; 
include "../config/koneksi.php";

#Variabel URL (register global)
$kdubah = $_REQUEST['kdubah'];
if ($kdubah !="") {
#menampilkan data
	$sql = "SELECT * FROM tb_laptop
		WHERE id_laptop='$kdubah'";
	$qry = mysql_query ($sql, $koneksi)
		or die ("SQL Error" .mysql_error());
	$data=mysql_fetch_array($qry);
	
# Samakan dgn variabel form
$TxtKodeH  = $data['id_laptop'];
	$TxtLaptop = $data['nama_laptop'];
	$TxtKeterangan = $data['keterangan'];
	$TxtSolusi  = $data ['solusi'];
}
?>
<html>
<head>
<title> Merubah Data laptop </title>
</head>
<body>
<form name="form1" method="post"
action="simpaneditlaptop.php">
  <div align="center">
    <table width="450" border="0" cellpadding="2"
cellspacing="1" bgcolour="#DBEAF5">
      <tr>
        <td colspan="2" bgcolour="#77B6DO">
        <b>Merubah Data laptop </b></td>
    </tr>
      <tr bgcolour="#FFFFFF">
        <td>Kode</td>
    <td><input name="TxtKode" type"text"
maxlength="4" size="6" value="<?php echo $TxtKodeH; ?>"
disabled="disabled">
      <input name="TxtKodeH" type="hidden"
	value="<?php echo $TxtKodeH; ?>"> </td> </tr>
      <tr bgcolour="#FFFFFF">
        <td width="77">laptop </td>
	    <td width="361">
	      <input name="Txtlaptop" type="text"
			maxlength="100" size="45"
			value="<?php echo $TxtLaptop; ?>"></td>
		      </tr>
      
      <tr bgcolour="#FFFFFF">
        <td>Keterangan</td>
	    <td><textarea name="TxtKeterangan" cols="40"
	rows="4"><?php echo $TxtKeterangan; ?></textarea> </td>
      </tr>
      <tr bgcolour="#FFFFFF">
        <td>Solusi<td>
        <td><textarea name="TxtSolusi" cols="40"
	rows="4"><?php echo $TxtSolusi; ?> </textarea></td>
    </tr>
      <tr bgcolour="#FFFFFF">
        <td>&nbsp;</td>
    <td><input type="submit" name="Submit"
value="Simpan"></td>
    </tr>
    </table>
  </div>
</form>
</body></html>