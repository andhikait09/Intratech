<?php 
include "session.php"; 
include "../config/koneksi.php";
	
# Baca variabel Form (If Register Global ON)

$TxtGejala 	= $_REQUEST['TxtGejala'];

# Validasi Form
if (trim($TxtGejala)=="") {
	echo "Gejala masih kosong, ulangi kembali";
	include "formgejala.php";
}
else {
	$sql  = " INSERT INTO tb_gejala (nama_gejala) ";
	$sql .=	" VALUES ('$TxtGejala')";
	mysql_query($sql, $koneksi) 
		  or die ("SQL Error".mysql_error());

	$pesan= "Data berhasil disimpan";
	header("Location: formgejala.php?pesan=$pesan");
}
?>
