<?php 
//include "inc.session.php"; 
//include "menu.php"; 
include "../config/koneksi.php";

$kdubah = $_REQUEST['kdubah'];
if ($kdubah !="") {
	#tampilin data bray
	$sql = "SELECT * FROM tb_gejala WHERE id_gejala='$kdubah'";
	$qry = mysql_query($sql, $koneksi)
		or die ("SQL Error".mysql_error());
		$data=mysql_fetch_array($qry);
		
	#menyamain dengan variabel + form
	//pindah data ke variabel
	$TxtGejala = $data['nama_gejala'];
	$TxtKodeH = $data['id_gejala'];
	}
?>
<html> <head> <title> Merubah Data Parameter </title> </head>
<body>
<form name="form1" method="post"
action="simpaneditgejala.php">
  <div align="center">
    <table width="400" border="0" cellpading="2"
cellspacing="1" bgcolor="#77B6D0">
      <tr>
        <td colspan="2"><b>MERUBAH PARAMETER LAPTOP</b></td>
    <tr>
      <tr bgcolor="#FFFFFF">
        <td>Kode</td>
    <td><input name="TxtKode" type="text"
	maxlength="4" size="6" value="<?php echo $TxtKodeH; ?>"
	disabled="disabled">
      <input name="TxtKodeH" type="hidden"
		value="<?php echo $TxtKodeH; ?>"></td>
    </tr>
      <tr bgcolor="FFFFFF">
        <td width="77">Parameter</td>
    <td width="361">
      <textarea name="TxtGejala" cols="35" rows="3">
	<?php echo $TxtGejala; ?></textarea></td>
    </tr>
      <tr bgcolor="#FFFFFF">
        <td>&nbsp;</td>
         <td><input type="submit" name="Submit"
value="Simpan"></td>
      </tr>
    </table>
  </div>
</form>
</body></html>