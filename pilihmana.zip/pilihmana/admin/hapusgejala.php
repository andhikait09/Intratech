<?php 
include "session.php"; 
include "../config/koneksi.php";

# Baca variabel URL (If Register Global ON)
$kdhapus = $_REQUEST['kdhapus'];

if ($kdhapus !="") {	
	$sql = "DELETE FROM tb_gejala	WHERE id_gejala='$kdhapus'";
	mysql_query($sql, $koneksi) 
		  or die ("SQL Error".mysql_error());
		  
	$sql2 = "DELETE FROM tb_relasi WHERE id_gejala='$kdhapus'";
	mysql_query($sql2, $koneksi);
		
	echo "DATA GEJALA BERHASIL DIHAPUS";
	include "tampilgejala.php";
}
else {
	echo "DATA GEJALA PEBLUM DIPILIH";
}
?>
