<?php 
include "session.php"; 
include "../config/koneksi.php";
include "menu.php"; 
$kdsakit = $_REQUEST['kdsakit'];
?>
<html>
<head>
<title>Halaman Buat Relasi Parameter Laptop</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore) {//v3.0 eal (targ+".location='"+selObj.options[selObj. selectedIndex].value+"'");
if (restore) selObj.selectedIndex=0;
}
//->
</script>
</head> <body>
<form name="form1" method="post"
action="simpanrelasi.php">
  <div align="center">
    <table width="100%" border="0" cellpadding="2"
cellspacing="1"bgcolor="#DBEAF5">
      <tr bgcolor="#DBEAF5">
        <td height="48" colspan="2" align="center">
      <b> [ RELASI PARAMETER DAN LAPTOP ] </b> </td> </tr>
     <tr>
        <td colspan="2" bgcolor="#DBEAF5">
        <b>Nama laptop : </b> </td>
    </tr>
      <td colspan="2" bgcolor="#DBEAF5">
        <select name="Cmblaptop" 
		onChange=MM_jumpMenu ('parent',this,0)">
          <option value="<?php $_SERVER['PHP_SELF'];?>">
            [ Daftar laptop ] </option>
          <?php
$sqlp = "SELECT * FROM tb_laptop ORDER BY id_laptop";
$qryp = mysql_query($sqlp, $koneksi)
	or die ("SQL Error: ".mysql_error());
while ($datap=mysql_fetch_array($qryp)) {
// Untuk Nilai Terpilih
if ($datap['id_laptop']==$kdsakit) {
	$cek ="selected";
	}
	else {
		$cek ="";
	}
	//kode untuk tampilin daftar
	echo "<option value='$datap[id_laptop]','$cek'>
		$datap[nama_laptop]
		</option>:";
		}
		$kdsakit=$datap['id_laptop'];
	?>
          </select>
        <input name="TxtKodeH" type="hidden"
		value="<?php $kdsakit; ?>"></td>
		    </tr>
      <tr>
        <td colspan="2" bgcolor="#DBEAF5">
          <b>Daftar Parameter</b></td>
		      </tr>
      <?php
		$sql = "SELECT * FROM tb_gejala ORDER BY id_gejala" ;
		$qry = mysql_query($sql, $koneksi)
			or die ("SQL Error: ".mysql_error());
			$no=1;
		while ($data=mysql_fetch_array($qry)) {
		//$no++;
			$sqlr = "SELECT * FROM tb_rule WHERE id_laptop='$datap[id_laptop]' AND id_gejala='$data[id_gejala]'";
			$qryr = mysql_query($sqlr, $koneksi);
			$cocok= mysql_num_rows($qryr);
			// kode nilai gejala terpilih
			// kode warna pada nilai terpilih
				if ($cocok==1) {
					$cek = " checked" ;
					$bg = "#CCFF00";
					}
					else {
						$cek = "";
						$bg  = "#FFFFFF";
					}
	?>
      <tr bgcolor="#FFFFFF">
        <td width="20" bgcolor="<?php $bg; ?>">
        
        <input type='checkbox' value='<?php echo $data['id_gejala'];?>=<?php $cek; ?>' name='CekGejala[]'/> 
        
        
      
		<?php 
		$no++;
		?>
		
		
		</td>
		<td width="100%"><?php echo $data['nama_gejala']; ?></td>
	      </tr>
      <?php
		}
		?>
    <tr bgcolor="#DBEAF5">
        <td colspan="2" align="center" bgcolor="DBEAF5">
          <input type="submit" name="Submit" value="Simpan Relasi">
          <input type="reset" name="reser" value="Normalkan"></td>
	</tr> 
    </table>
  </div>
</form> 
</body> </html>
