<?php 
include "session.php"; 
include "menu.php"; 
include "../config/koneksi.php";
$kdsakit = $_REQUEST['kdsakit'];
?>
<html>
<head>
<title>Halaman Buat Relasi Parameter laptop</title>
</head>
<body>
<form name="form1" method="post" action="laporangejala2.php">
  <div align="center">
    <table width="400" border="0" cellpadding="2" cellspacing="1" bgcolor="#99FFFF">
      <tr>
        <td colspan="2" bgcolor="#DBEAF5" align="center"><b>TAMPILKAN PARAMETER PER LAPTOP </b></td>
      </tr>
      <tr>
        <td width="93" bgcolor="#ffffff"><b>laptop :</b></td>
      <td width="346" bgcolor="#ffffff">
        <select name="Cmblaptop">
          <option value="NULL">[ Daftar laptop ]</option>
          <?php 
	$sqlp = "SELECT * FROM tb_laptop ORDER BY id_laptop";
	$qryp = mysql_query($sqlp, $koneksi) 
		    or die ("SQL Error: ".mysql_error());
	while ($datap=mysql_fetch_array($qryp)) {
		if ($datap['id_laptop']==$kdsakit) {
			$cek ="selected";
		}
		else {
			$cek ="";
		}
		echo "<option value='$datap[id_laptop]' $cek>
			  $datap[nama_laptop] ($datap[id_laptop])</option>";
	}
  ?>
        </select></td>
    </tr>
      <tr bgcolor="#DBEAF5"> 
        <td align="center" bgcolor="#DBEAF5">&nbsp;</td>
      <td bgcolor="#DBEAF5"><input type="submit" name="Submit" value="Tampil"></td>
    </tr>
    </table>
  </div>
</form>
</body>
</html>
