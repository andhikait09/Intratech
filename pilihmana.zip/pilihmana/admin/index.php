<?php
include ('session.php'); 
include ('menu.php'); 
?>
<html>
<head>
<title></title>
</head>
<body>
</body>
</html>