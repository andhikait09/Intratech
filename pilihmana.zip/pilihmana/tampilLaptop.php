<?php 
include "config/koneksi.php";
?>

<table width="512" border="1" align="center" cellpadding="2" cellspacing="1" bgcolor="#22B5DD" background="image/HeaderTable.png">
  <tr bgcolor=""> 
    <td colspan="4"><div align="center"><b>DAFTAR SEMUA PENYAKIT</b></div></td>
  </tr>
  <tr bgcolor="#DBEAF5"> 
    <td width="23"><div align="center"><b>No</b></div></td>
    <td width="181"><div align="center"><b>Nama Penyakit</b></div></td>
    <td width="223"><div align="center"><b>Solusi </b></div></td>
    <td width="54" align="center"><div align="center"><strong>Pilih</strong></div></td>
  </tr>
  <?php 
	$sql = "SELECT * FROM tb_penyakit ORDER BY id_penyakit asc";
	$qry = mysql_query($sql, $koneksi) 
		 or die ("SQL Error".mysql_error());
	while ($data=mysql_fetch_array($qry)) {
	$no++;
  ?>
  <tr bgcolor="#FFFFFF"> 
    <td bgcolor="#FFFFFF"><?php echo $no; ?></td>
    <td><?php echo $data['nama_penyakit']; ?></td>
    <td bgcolor="#FFFFFF"><?php echo $data['solusi']; ?></td>
    <td align="center" bgcolor="#FFFFFF"><a href="?page=dafgejala&idsakit=<?php echo $data['id_penyakit'];?>">Lihat</a></td>
  </tr>
  <?php
  }
  ?>
</table>


<div class="card">
	<div class="body">
		<table id="mainTable" class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Solusi</th>
                    <th>Aksi</th>
                </tr>
            </thead>	
			<?php 
				$sql = "SELECT * FROM tb_laptop ORDER BY id_laptop asc";
				$qry = mysql_query($sql, $koneksi) 
					or die ("SQL Error".mysql_error());
				while ($data=mysql_fetch_array($qry)) {
				$no++;
			?>
            <tbody>
                <tr>
                    <td><?php echo $no; ?></td>
                    <td><?php echo $data['nama_penyakit']; ?></td>
                    <td><?php echo $data['solusi']; ?></td>
                    <td>0</td>
                </tr>
            </tbody>			
		</table>
	</div>
</div>
