<?php 
include "config/koneksi.php";
?>
<html>
<head>
<title>Form Masukan Data Pembeli</title>
</head>
<body>
<form action="simpanDaftar.php" method="post" name="form1" target="_self">
  <table width="200" border="0"align="center" >
    <tr>
      
      <td><table width="400" border="0"cellpadding="2" cellspacing="1" bgcolor="#DBEAF5">
        <tr>
          <td colspan="2"><b>Silahkan inputkan profile anda</b></td>
        </tr>
        <tr bgcolor="#FFFFFF">
          <td>Nama</td>
          <td><input name="TxtNama" type="text" value="<?php $TxtNama; ?>" size="35" maxlength="60"></td>
        </tr>
        <tr bgcolor="#FFFFFF">
          <td width="76">Umur</td>
          <td width="312"><input name="TxtUmur" type="text" value="<?php $TxtUmur; ?>" size="35" maxlength="60"></td>
        </tr>
        <tr bgcolor="#FFFFFF">
          <td width="76">Alamat</td>
          <td width="312"><input name="TxtAlamat" type="text" value="<?php $TxtAlamat; ?>" size="35" maxlength="60"></td>
        </tr>
        <tr bgcolor="#FFFFFF">
          <td width="76">Email</td>
          <td width="312"><input name="TxtEmail" type="text" value="<?php $TxtEmail; ?>" size="35" maxlength="60"></td>
        </tr>
         <tr bgcolor="#FFFFFF">
          <td width="76">Username</td>
          <td width="312"><input name="TxtUsername" type="text" value="<?php $TxtUsername; ?>" size="35" maxlength="60"></td>
        </tr>
         <tr bgcolor="#FFFFFF">
          <td width="76">Password</td>
          <td width="312"><input name="TxtPassword" type="text" value="<?php $TxtPassword; ?>" size="35" maxlength="60"></td>
        </tr>
        <tr bgcolor="#FFFFFF">
          <td>&nbsp;</td>
          <td><input type="submit" name="Submit" value="Login"></td>
        </tr>
        <tr bgcolor="#FFFFFF">
        <td>&nbsp;</td>
        <td><a href="">Daftar sebagai member baru</a></td>
        </tr>
      </table></td>
    </tr>
  </table>
  </form>
</body>
</html>



<section id="main-slider" class="no-margin"> 
  <div class="carousel slide">
    <div class="carousel-inner">
      <div class="item active" style="background-image: url(images/slider/bg1.jpg)">
        <div class="container">
          <div class="row slide-margin">
		  
			<form action="simpanDaftar.php" method="post" name="form1" target="_self">
            <div class="col-sm-6">
				<div class="carousel-content">
					<div class="form-group">
						<h3 class="animation animated-item-1" style="color:#fff;"><span>Silahkan isi data anda . . . </span></h3>
						<div class="box-body col-xs-8">
							<div class="form-group">
								<input name="TxtNama" type="text" value="<?php $TxtNama; ?>" class="form-control animation animated-item-2" placeholder="Nama...">
							</div>
							<div class="form-group">
								<input name="TxtUmur" type="text" value="<?php $TxtUmur; ?>" class="form-control animation animated-item-2" placeholder="Umur...">
							</div>
							<div class="form-group">
								<input name="TxtAlamat" type="text" value="<?php $TxtAlamat; ?>" class="form-control animation animated-item-2" placeholder="Alamat...">
							</div>
							<div class="form-group">
								<input name="TxtEmail" type="text" value="<?php $TxtEmail; ?>" class="form-control animation animated-item-2" placeholder="Email...">
							</div>
							<div class="form-group">
								<input name="TxtUsername" type="text" value="<?php $TxtUsername; ?>" class="form-control animation animated-item-2" placeholder="Username...">
							</div>
							<div class="form-group">
								<input name="TxtPassword" type="text" value="<?php $TxtPassword; ?>" class="form-control animation animated-item-2" placeholder="Password...">
							</div>
							<div class="form-group">
								<input type="submit" name="Submit" value="DAFTAR" class="btn-slide animation animated-item-3">
							</div>
						</div>
					</div>
				</div>
            </div>

            <div class="col-sm-6 hidden-xs animation animated-item-4">
              <div class="slider-img">
                <img src="images/slider/img3.png" class="img-responsive">
              </div>
            </div>
			</form>
			
          </div>
        </div>
      </div>
      <!--/.item-->
    </div>
    <!--/.carousel-inner-->
  </div>
  <!--/.carousel-->
</section>