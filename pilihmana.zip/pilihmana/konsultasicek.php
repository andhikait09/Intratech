<?php 
//session_start();
include "config/koneksi.php";
	
# Baca variabel Form (If Register Global ON)
$RbPilih 	= $_REQUEST['RbPilih'];
$TxtidGejala= $_REQUEST['TxtidGejala'];


$userID=$_SESSION['userID'];


# PEMERIKSAAN
if ($RbPilih == "YA") {
	//$sql_analisa = "SELECT * FROM tb_temp where id_user='$userID'";
//	$qry_analisa = mysql_query($sql_analisa, $koneksi);
//	$data_cek = mysql_num_rows($qry_analisa);
	//if ($data_cek >= 1) {
		
	$jwb='YA';
	
	$sqlJawab=mysql_query("insert into tb_temp(id_gejala,jawaban,id_user) values ('$TxtidGejala','$jwb','$userID')");
	
	//}
	echo "<meta http-equiv='refresh' content='0; url=index.php?page=konsul'>";
	
	

}else{
	//$sql_analisa = "SELECT * FROM tb_temp where id_user='$userID'";
	//$qry_analisa = mysql_query($sql_analisa, $koneksi);
	//$data_cek = mysql_num_rows($qry_analisa);
	//if ($data_cek >= 1) {
	$jwb='NO';
	$sqlJawab=mysql_query("insert into tb_temp(id_gejala,jawaban,id_user) values ('$TxtidGejala','$jwb','$userID')");
	
	//}
	echo "<meta http-equiv='refresh' content='0; url=index.php?page=konsul'>";
}
?>