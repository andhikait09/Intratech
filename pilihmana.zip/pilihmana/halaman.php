<?php
error_reporting(E_ALL & ~E_NOTICE);

$page= @$_REQUEST['page'];
if ($page=="jenisLaptop") {
	if(file_exists ("tampilLaptop.php")) {
		include "tampilLaptop.php";
	}
	else {
		echo "Data Laptop Tidak ditemukan";
	}
}
elseif ($page=="dafgejala") {
	if(file_exists ("tampilgejala.php")) {
		include "tampilgejala.php";
	}
	else {
		echo "Data Gejala Tidak ditemukan";
	}
}

elseif($page=="daftar"){
	if(file_exists("formdaftaruser.php")){
		include"formdaftaruser.php";	
	}else{
		echo "Form daftar tidak di temukan";	
	}
}

elseif($page=="ceklogin"){
	if(file_exists("cekloginuser.php")){
		include "cekloginuser.php";	
	}else{
		include "Form tidak ditemukan";	
	}
}
elseif($page=="login"){
	if(file_exists("formloginuser.php")){
		include"formloginuser.php";	
	}else{
		echo "Anda harus daftar terlebih dahulu";	
	}
}
elseif ($page=="konsul") {
	if(file_exists ("konsultasi.php")) {
		include "konsultasi.php";
	}
	else {
		echo "Data Konsultasi Tidak ditemukan";
	}
}
elseif ($page=="konsulcek") {
	if(file_exists ("Konsultasicek.php")) {
		include "Konsultasicek.php";
	}
	else {
		echo "Data Konsultasi Tidak ditemukan";
	}
}
elseif ($page=="hasil") {
	if(file_exists ("hasilanalisa.php")) {
		include "hasilanalisa.php";
	}
	else {
		echo "Data Hasil Tidak ditemukan";
	}
}
elseif ($page=="tolong") {
	if(file_exists ("penjelasan.htm")) {
		include "penjelasan.htm";
	}
	else {
		echo "Data Penjelasan Tidak ditemukan";
	}
}
elseif($page=="about"){
if(file_exists("About.html")){
include "about.html";	
}else{
	echo "Halaman utama tidak ditemukan";
	}
}

elseif ($page=="beranda") {
	if(file_exists ("beranda.php")) {
		include "beranda.php";
	}
	else {
		echo "Halaman Utama Tidak ditemukan";
	}
}

elseif ($page=="koment"){
if(file_exists ("formbukutamu.php")){
	include "formbukutamu.php";
}else{
	echo "Halaman Buku Tamu Tidak ditemukan";
}
}
elseif ($page=="") {
	if(file_exists ("home.php")) {
		include "home.php";
	}
	else {
		echo "FILE HALAMAN UTAMA ADA";
	}
}
?>