<?php 
include "config/koneksi.php";
$userID=$_SESSION['userID'];

//$sessionID = $_SERVER['REMOTE_ADDR'];
$sql = "SELECT tb_hasil_analisa.*, tb_laptop.* 
		FROM tb_hasil_analisa,tb_laptop 
		WHERE tb_laptop.id_laptop=tb_hasil_analisa.id_laptop
		AND tb_hasil_analisa.id_user='$userID'
		ORDER BY tb_hasil_analisa.id_analisa DESC LIMIT 1";
$qry = mysql_query($sql, $koneksi) 
	   or die ("Query Hasil salam".mysql_error());
$data= mysql_fetch_array($qry);


?>

<section id="main-slider" class="no-margin"> 
  <div class="carousel slide">
    <div class="carousel-inner">
      <div class="item active" style="background-image: url(images/slider/bg1.jpg)">
        <div class="container">
          <div class="row slide-margin">
            <div class="col-sm-6">
              <div class="carousel-content">
                <h2 class="animation animated-item-1"><span><b>HASIL ANALISA</b></span></h2>
                <p class="animation animated-item-2">Merek  : <?php echo $data['nama_laptop']; ?></p>
				<p class="animation animated-item-2">Solusi : <?php echo $data['solusi']; ?></p>
				<p class="animation animated-item-2">Kebutuhan : <br>
				<?php 		
				//$sql_gejala = "SELECT tb_gejala.* FROM tb_gejala,tb_rule
				//						WHERE tb_gejala.id_gejala=tb_rule.id_gejala
				//						AND tb_rule.id_laptop='$data[id_laptop]'";
				$sql_gejala="select tb_gejala.* from tb_gejala, tb_temp where tb_gejala.id_gejala=tb_temp.id_gejala and tb_temp.jawaban='YA' and tb_temp.id_user='$userID'";
				$qry_gejala = mysql_query($sql_gejala, $koneksi);
				while ($hsl_gejala=mysql_fetch_array($qry_gejala)) {
				$i++;
					echo "$i . $hsl_gejala[nama_gejala] <br>";
				}				
				?>
				</p>				
				
				<p class="animation animated-item-3">Rekomendasi laptop untuk anda  : <?php echo $data['nama_laptop']; ?> <?php echo $data['persentase']; ?>% </p>
				
				<a class="btn-slide animation animated-item-3" href="Logout.php">Logout . . .</a>
              </div>
			  
			  
            </div>

            <div class="col-sm-6 hidden-xs animation animated-item-4">
              <div class="slider-img">
                <img src="images/slider/img3.png" class="img-responsive">
              </div>
            </div>

          </div>
        </div>
      </div>
      <!--/.item-->
    </div>
    <!--/.carousel-inner-->
  </div>
  <!--/.carousel-->
</section>