<?php 

include "config/koneksi.php";

$userID=$_SESSION['userID'];
if($userID==""){
	echo "<meta http-equiv='refresh' content='0; url=index.php?page=login'>";
}

#hitung jumlah parameter
$GejalaQuery="select count(*) as 'Jum' from tb_gejala";
$jumGejala=mysql_query($GejalaQuery,$koneksi);
$jumx=mysql_fetch_array($jumGejala);
$jumlah=$jumx['Jum'];


# cek jumlah pertanyaan yg sudah di jawab
$sqlcek = "SELECT * FROM tb_temp WHERE id_user='$userID'";
$qrycek = mysql_query($sqlcek, $koneksi);
$datacek= mysql_num_rows($qrycek);

		
#Jika semua pertanya telah di jawab
if ($datacek >= $jumlah) {
	#hitung jumlah jawaban YA
	$hitYA="select count(*) as 'JmlYA' from tb_temp where jawaban='YA' and id_user='$userID'";
	$hotYA=mysql_query($hitYA,$koneksi);
	$Qya=mysql_fetch_array($hotYA);
		$totalYA=$Qya['JmlYA'];
	
	#perhitungan similarity : rumus = ((total YA) / (total parameter))*100 
	$hasil=($totalYA/$jumlah)*100;
	$hasilnya=ceil($hasil);
	
	$proses="select tb_rule.*, tb_laptop.id_laptop, tb_laptop.nama_laptop, tb_laptop.keterangan, tb_laptop.solusi from tb_rule join tb_laptop where id_gejala in (select id_gejala from tb_temp where jawaban='YA' and id_user='$userID') and tb_rule.id_laptop=tb_laptop.id_laptop order by tb_rule.id_laptop desc";
	
	//$proses="select tb_gejala.* from tb_gejala join tb_temp where tb_temp.id_gejala in (select id_gejala from tb_temp where id_user='$userID') and tb_temp.id_gejala=tb_gejala.id_gejala order by tb_gejala.id_gejala LIMIT 1";
	
	$prosesx=mysql_query($proses,$koneksi);
	$xhasil=mysql_fetch_array($prosesx);
	$idpk=$xhasil['id_laptop'];
	
	#select user
		$sqlPasien="select * from tb_user where id_user='$userID'";
		$qryPasien=mysql_query($sqlPasien,$koneksi);
		$dataPembeli=mysql_fetch_array($qryPasien);
		$nama=$dataPembeli['nama'];
		$umur=$dataPembeli['umur'];
		$alamat=$dataPembeli['alamat'];
		$email=$dataPembeli['email'];


	$sqlIn="insert into tb_hasil_analisa (id_user,nama,umur,alamat,email,id_laptop,waktu,persentase) values ('$userID', '$nama', '$umur', '$alamat', '$email', '$idpk', NOW(),'$hasilnya')";
	mysql_query($sqlIn, $koneksi);
	echo "<meta http-equiv='refresh' content='0; url=index.php?page=hasil'>";
	exit;
}

if ($datacek>=1) {
	$sqlg="select * from tb_gejala where not exists(select * from tb_temp where tb_gejala.id_gejala=tb_temp.id_gejala and tb_temp.id_user='$userID') order by tb_gejala.id_gejala LIMIT 1";
 		$qryg = mysql_query($sqlg,$koneksi);
		while($datag = mysql_fetch_array($qryg)){	
		$idgejala = $datag['id_gejala'];
		$gejala   = $datag['nama_gejala'];	
		}		
}
else {
	// Seandainya tmp kosong
	$sqlg = "SELECT * FROM tb_gejala ORDER BY id_gejala asc LIMIT 1";
	$qryg = mysql_query($sqlg,$koneksi);
	while($datag = mysql_fetch_array($qryg)){;
	$idgejala = $datag['id_gejala'];
	$gejala   = $datag['nama_gejala'];
	}
}
?>


<section id="main-slider" class="no-margin"> 
  <div class="carousel slide">
    <div class="carousel-inner">
      <div class="item active" style="background-image: url(images/slider/bg1.jpg)">
        <div class="container">
          <div class="row slide-margin">
            <div class="col-sm-6">
              <div class="carousel-content">			  
				<div class="box box-primary">
					
					<div class="box-header with-border">
						<h3 style="color:white;" class="box-title">Jawablah pertanyaan berikut . . .</h3>
					</div>	
					
					<form action="?page=konsulcek" method="post" name="form1" target="_self">
					<p class="animation animated-item-1">Apakah anda membutuhkan <?php echo $gejala; ?> ?</p>
					<input name="TxtidGejala" type="hidden" value="<?php echo $idgejala; ?>">
					
					<div class="radio animation animated-item-2">
						<div class="radio">
							<label>
								<input type="radio" name="RbPilih" value= "YA" checked>Benar (YA)
							</label>
						</div>					
						<div class="radio">
							<label>
								<input type="radio" name="RbPilih" value="TIDAK">Salah (TIDAK)
							</label>
						</div>					
					</div>
					
					<input type="submit" name="Submit" value="Jawab" class="btn-slide animation animated-item-3">
				
					</form>
				</div>
              </div>
            </div>

            <div class="col-sm-6 hidden-xs animation animated-item-4">
              <div class="slider-img">
                <img src="images/slider/img3.png" class="img-responsive">
              </div>
            </div>

          </div>
        </div>
      </div>
      <!--/.item-->
    </div>
    <!--/.carousel-inner-->
  </div>
  <!--/.carousel-->
</section>
