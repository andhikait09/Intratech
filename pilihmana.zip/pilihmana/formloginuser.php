<?php 
include "config/koneksi.php";
?>

  <section id="main-slider" class="no-margin"> 
    <div class="carousel slide">
      <div class="carousel-inner">
        <div class="item active" style="background-image: url(images/slider/bg1.jpg)">
          <div class="container">
            <div class="row slide-margin">
              <div class="col-sm-6">
                <div class="carousel-content">
				
				<form action="?page=ceklogin" method="post" name="form1" target="_self">
				<div class="box-body">
                  <p class="animation animated-item-1"><b>Silahkan login terlebih dahulu</b></p>
					<div class="form-group">
						<input name="TxtUser" value="<?php $TxtUsername; ?>" type="text" class="form-control animation animated-item-2" placeholder="USERNAME">
					</div>
					<div class="form-group">	
						<input name="TxtPassword2" value="<?php $TxtPassword; ?>" type="text" class="form-control animation animated-item-2" placeholder="PASSWORD">
					</div>					
					<div class="form-group">
						<input type="submit" name="Submit" value="LOGIN SEKARANG" class="btn-slide animation animated-item-3">
						<a class="btn-slide animation animated-item-4" href="?page=daftar">Daftar baru . . . </a>
					</div>  					
				</div>
				</form>
				
                </div>
              </div>

			  
            </div>
          </div>
        </div>
        <!--/.item-->
      </div>
      <!--/.carousel-inner-->
    </div>
    <!--/.carousel-->
  </section>